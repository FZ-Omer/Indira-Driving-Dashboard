<?php

session_start();
if (isset($_POST['login'])) {
    extract($_POST);
    include 'connect.php';

    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql = mysqli_query($conn, "SELECT * FROM staff WHERE username='$username' AND password='$password'");
    $row = mysqli_fetch_array($sql);
    if (is_array($row)) {
        $_SESSION["user_id"] = $row['id'];
        $_SESSION["Name"] = $row['name'];

        $role = $row['role'];
        if ($role == 'staff_grade_1') {
            $_SESSION['role'] = 'staff_grade_1';
            header("Location: template/staff/dashboard.php");
        } elseif ($role == 'staff_grade_2') {
            $_SESSION['role'] = 'staff_grade_2';
            header("Location: template/staff2/dashboard.php");
        } elseif ($role == 'instructor') {
            $_SESSION['role'] = 'instructor';
            header("Location: template/instructor/dashboard.php");
        } else {
            // Handle other roles or error cases here
        }
        exit;
    } else {
        $error = 'Your Email or Password is Incorrect! Please Check and Try Again';
        header("Location: index.php?error=" . urlencode($error));
        exit;
    }
}

?>