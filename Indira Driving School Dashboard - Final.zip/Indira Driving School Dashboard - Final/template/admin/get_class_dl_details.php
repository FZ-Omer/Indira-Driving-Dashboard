<?php
// Database connection and query to retrieve class names and details
include("../../connect.php");

$selectedClass = $_POST["class"]; // Assuming you are sending the selected class in the AJAX request

if ($selectedClass === "DL") {
  // Retrieve RC class details
  $sql = "SELECT * FROM classes_dl";
  $result = $conn->query($sql);

  // Build the HTML table to display the class details
  $html = '<table class="table">';
  $html .= '<thead><tr><th>ID</th><th>Class Name</th><th>Fees</th><th>No Of Days</th></tr></thead>';
  $html .= '<tbody>';
  // Loop through the query results and create table rows
  while ($row = $result->fetch_assoc()) {
    $html .= '<tr>';
    $html .= '<td>' . $row['id'] . '</td>';
    $html .= '<td>' . $row['class_name'] . '</td>';
    $html .= '<td>' . $row['fees'] . '</td>';
    $html .= '<td>' . $row['nfd'] . '</td>';
    $html .= '</tr>';
  }
  $html .= '</tbody>';
  $html .= '</table>';

  // Retrieve all class names and details
  $sqlClassNames = "SELECT class_name, fees, nfd FROM classes_dl";
  $resultClassNames = $conn->query($sqlClassNames);
  $classDetails = array();
  while ($rowClassName = $resultClassNames->fetch_assoc()) {
    $classDetails[] = array(
      'class_name' => $rowClassName['class_name'],
      'fees' => $rowClassName['fees'],
      'nfd' => $rowClassName['nfd']
    );
  }

  // Build the HTML dropdown to display class names
  $dropdownHtml = '<select id="className" name="classname" class="form-control" placeholder="Class Name" aria-label="classname">';
  foreach ($classDetails as $classDetail) {
    $dropdownHtml .= '<option value="' . $classDetail['class_name'] . '">' . $classDetail['class_name'] . '</option>';
  }
  $dropdownHtml .= '</select>';

  // Return the HTML table, dropdown, and class details as a JSON response
  $response = array(
    'table' => $html,
    'dropdown' => $dropdownHtml,
    'classDetails' => $classDetails
  );

  echo json_encode($response);
} else {
  echo ""; // Return an empty response if no class is selected or if the selected class is not RC
}
?>
