<?php
include("../../connect.php");

if (isset($_POST['update'])) {
  $class_id = $_POST['class_id'];
  $class_name = $_POST['class_name'];
  $working  = $_POST['working'];
  $fees = $_POST['fees'];
  $nfd = $_POST['nfd'];


  // Update the class details in the database
  $sql = "UPDATE classes_rc SET class_name='$class_name', working='$working', fees='$fees', nfd='$nfd' WHERE id='$class_id'";
  $result = $conn->query($sql);

  if ($result === TRUE) {
    $error = 'Your RC Class Details Updated Successfully!';
    header("Location: classes_list.php?error=" . urlencode($error));
    exit;
  } else {
    echo "Error: " . $sql . "<br>" . $conn->mysqli_error($conn);
  }
}
?>