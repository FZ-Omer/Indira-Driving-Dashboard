<?php
include '../../connect.php';

$query = "SELECT class_name FROM classes_rc";
$result = mysqli_query($conn, $query);

$courses = array();
while ($row = mysqli_fetch_assoc($result)) {
    $courses[] = $row['class_name'];
}

// Close the database connection
mysqli_close($conn);

// Send the course names as a JSON response
header('Content-Type: application/json');
echo json_encode($courses);
?>
