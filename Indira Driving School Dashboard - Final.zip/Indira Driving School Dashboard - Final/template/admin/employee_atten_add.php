<?php
include("../../connect.php");

// Retrieve the student details from the database
$query = "SELECT id, name FROM staff";
$result = mysqli_query($conn, $query);

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  // Retrieve the attendance data from the form
  $attendanceData = $_POST['attendance'];
  $name = $_POST['name'];

  // Get the current date
  $currentDate = date('Y-m-d');

  // Loop through the attendance data and update the database
  foreach ($attendanceData as $studentID => $attendanceDates) {
    foreach ($attendanceDates as $attendanceDate => $attendanceStatus) {
      // Check if the attendance record already exists for the current date and staff member
      $query = "SELECT * FROM attendance WHERE student_id = '$studentID' AND date = '$currentDate'";
      $result = mysqli_query($conn, $query);

      if ($result && mysqli_num_rows($result) > 0) {
        // Attendance record already exists, skip insertion
        continue;
      }

      // Insert the attendance record with the staff name
      $query = "INSERT INTO attendance (student_id, date, status) VALUES ('$studentID', '$attendanceDate', '$attendanceStatus')";
      mysqli_query($conn, $query);
    }
  }

  // Redirect back to the attendance page
  header("Location: employee_atten_list.php");
  exit();
}

include("admin-header.php");
?>

<style>
  /* Your CSS styles */
</style>

<div class="container-fluid page-body-wrapper">
  <div class="main-panel">
    <div class="content-wrapper">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-md-8">
            <div class="card shadow-sm">
              <div class="card-header bg-danger text-white">
                <h1 class="mb-0">Staff Attendance</h1>
              </div>
              <div class="card-body">
                <div class="table-responsive">
                  <form action="" method="POST">
                    <table class="table">
                      <thead>
                        <tr>
                          <th>Employee ID</th>
                          <th>Employee Name</th>
                          <th>Attendance</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php
                        // Display student details and attendance checkboxes
                        if ($result && mysqli_num_rows($result) > 0) {
                          while ($row = mysqli_fetch_assoc($result)) {
                            $studentID = $row['id'];
                            $studentName = $row['name'];
                            ?>
                            <tr>
                              <td><?php echo $studentID; ?></td>
                              <td><?php echo $studentName; ?></td>
                              <td>
                                <input type="radio" name="attendance[<?php echo $studentID; ?>][<?php echo date('Y-m-d'); ?>]" value="P" <?php if (isset($attendanceData[$studentID][date('Y-m-d')]) && $attendanceData[$studentID][date('Y-m-d')] === 'Present') echo 'checked'; ?>> P
                                <input type="radio" name="attendance[<?php echo $studentID; ?>][<?php echo date('Y-m-d'); ?>]" value="A" <?php if (isset($attendanceData[$studentID][date('Y-m-d')]) && $attendanceData[$studentID][date('Y-m-d')] === 'Absent') echo 'checked'; ?>> A
                              </td>
                            </tr>
                            <?php
                          }
                        } else {
                          echo '<tr><td colspan="3">No employees found.</td></tr>';
                        }
                        ?>
                      </tbody>
                    </table>
                    <input type="hidden" name="name" value="<?php echo $name; ?>">
                    <div class="text-center">
                      <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php
include("admin-footer.php");
mysqli_close($conn);
?>
Make sure to replace the form action `""` with the appropriate URL if you want to submit the form to a specific page.