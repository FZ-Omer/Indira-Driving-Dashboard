


<?php
include("admin-header.php");
?>

<!-- partial -->
<div class="container-fluid page-body-wrapper">
  <div class="main-panel">
    <div class="content-wrapper">
      <div class="row" >
        
        
       
       
        <div class="col-md-8 grid-margin stretch-card" >
          <div class="card offset-3 " style="box-shadow: rgba(0, 0, 0, 0.56) 0px 22px 70px 4px;">
            <div class="card-header" style="background-color: #c55a0c;">
              <h1 class="text-white">Employee</h1>
              
            </div>
            <div class="card-body">
              <h4 class="card-title">Add Employee of Our Business</h4>
              <form action="employee_post.php" method="post">
                <div class="row">
                  <div class="col-6 form-group">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text text-white" style="background-color: #631e38;" ><i class="mdi mdi-account"></i></span>
                      </div>
                      <input name="name" type="text" class="form-control" placeholder="Full Name" aria-label="Full name">
                    </div>
                  </div>
                  <div class="col-6 form-group">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text text-white" style="background-color: #631e38;"><i class="mdi mdi-phone-plus"></i></span>
                      </div>
                      <input name="phone" type="text" class="form-control" placeholder="Phone Number" aria-label="Phone">
                      
                    </div>
                  </div>
                </div>

                <div class="row">
                 
                  <div class="col-12 form-group">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text text-white" style="background-color: #631e38;"><i class="mdi mdi-calendar-check"></i></span>
                      </div>
                      <input type="text" class="form-control" placeholder="Date_of_Joining" id="date_of_joining" name="date_of_joining" required> 
                    </div>
                  </div>
                </div>


                <h4 class="card-title">Salary Details</h4>
                
                <div class="row">
                  <div class="col-6 form-group">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text text-white" style="background-color: #631e38;" ><i class="mdi mdi-cash"></i></span>
                      </div>
                      <input name="salary_amount" type="text" class="form-control" placeholder="Salary Amount" aria-label="Salary Amount">
                    </div>
                  </div>
                  <div class="col-6 form-group">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text text-white" style="background-color: #631e38;"><i class="mdi mdi-calculator"></i></span>
                      </div>
                      <input type="text" class="form-control" placeholder="Salary Date" id="salary_date" name="salary_date" required> 
                      
                    </div>
                  </div>
                </div>

                <div class="row">
                  <div class="col-6 form-group">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text text-white" style="background-color: #631e38;" ><i class="mdi mdi-clipboard-check"></i></span>
                      </div>
                      <input name="daily_allowance" type="text" class="form-control" placeholder="Daily Allowance" aria-label="Daily Allowance">
                    </div>
                  </div>
                  <div class="col-6 form-group">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text text-white" style="background-color: #631e38;"><i class="mdi mdi-currency-inr"></i></span>
                      </div>
                      <input name="bonus" type="text" class="form-control" placeholder="Bonus" aria-label="Bonus">
                      
                    </div>
                  </div>
                </div>

                <div class="row">
                  <div class="col-6 form-group">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text text-white" style="background-color: #631e38;" ><i class="mdi mdi-clock"></i></span>
                      </div>
                      <input name="working_time" type="text" class="form-control" placeholder="Working Time" aria-label="Working Time">
                    </div>
                  </div>
                  <div class="col-6 form-group">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text text-white" style="background-color: #631e38;"><i class="mdi mdi-chevron-double-up"></i></span>
                      </div>
                      <input name="increment" type="text" class="form-control" placeholder="Increment" aria-label="Increment">
                      
                    </div>
                  </div>
                </div>
                

                <h4 class="card-title">Login Credentials </h4>
                
                <div class="row">
                  <div class="col-6 form-group">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text text-white" style="background-color: #631e38;" ><i class="mdi mdi-account-key"></i></span>
                      </div>
                      <input name="username" type="text" class="form-control" placeholder="User Name" aria-label="Username">
                    </div>
                  </div>
                  <div class="col-6 form-group">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text text-white" style="background-color: #631e38;"><i class="mdi mdi-eye-off"></i></span>
                      </div>
                      <input name="password" type="text" class="form-control" placeholder="Password" aria-label="Password">
                      
                    </div>
                  </div>
                </div>

                <div class="row">
                 
                  <div class="col-12 form-group">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text text-white" style="background-color: #631e38;"><i class="mdi mdi-account-switch"></i></span>
                      </div>
                      <select class="form-control" id="role" name="role">
                        <option>Select Staff</option>
                        <option value="instructor">Instructor</option>
                        <option value="staff_grade_1">Staff Grade 1</option>
                        <option value="staff_grade_2">Staff Grade 2</option>
                      </select>                     
                    </div>
                  </div>
                </div>

                <button type="submit" name="staff_details" class="btn btn-success ">Save</button>
              </form>
              <br>
              <a href="employee_list.php"> <button  class="btn btn-danger">Cancel</button></a> 
              
              
            </div>
          </div>
        </div>
        
        
        
        
        
        
      </div>
    </div>
    <!-- content-wrapper ends -->
    <!-- partial:../../partials/_footer.html -->
    
    <!-- partial -->
  </div>
  <!-- main-panel ends -->
</div>
<!-- page-body-wrapper ends -->


<?php
include("admin-footer.php");
?>
<!-- End custom js for this page-->
<script>
    // JavaScript code to provide placeholder-like behavior for the date input field
    const dateInput = document.getElementById('date_of_joining');
    dateInput.addEventListener('focus', function() {
      dateInput.type = 'date';
      dateInput.setAttribute('min', '1970-01-01'); // Optional: Set a minimum date if needed
    });
    dateInput.addEventListener('blur', function() {
      if (dateInput.value === '') {
        dateInput.type = 'text';
        dateInput.value = 'date_of_joining';
      }
    });
  </script>
  <script>
    // JavaScript code to provide placeholder-like behavior for the date input field
    const dateInput1 = document.getElementById('salary_date');
    dateInput1.addEventListener('focus', function() {
      dateInput1.type = 'date';
      dateInput1.setAttribute('min', '1970-01-01'); // Optional: Set a minimum date if needed
    });
    dateInput.addEventListener('blur', function() {
      if (dateInput1.value === '') {
        dateInput1.type = 'text';
        dateInput1.value = 'salary_date';
      }
    });
  </script>



