<?php 
include("../../connect.php");
$sql = "SELECT * FROM staff";
$result = $conn->query($sql);
?>

<?php
include("admin-header.php");
?>


<!-- partial -->
<div class="container-fluid page-body-wrapper">
  <div class="main-panel">
    <div class="content-wrapper">
      <div class="row">
        <div class="col-md-8 mx-auto mt-5">
          <div class="card shadow-sm">
            <div class="card-header bg-danger text-white">
              <h1 class="mb-0">Employees</h1>
            </div>
            <div class="card-body table-responsive">
            <?php
                   if(isset($_GET['error'])) {
                    $error = $_GET['error'];
                    echo '<div class="alert alert-success alert-dismissible" role="alert">
                    ' . $error . '
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                      </div>'; 
                     }
                ?>
              <table id="myTable" class="table table-striped table-bordered">
                <thead>
                  <tr>
                    <th>Full Name</th>
                    <th>User Name</th>
                    <th>Password</th>
                    <th>Role</th>
                    <th>Phone Number</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                      $class_id = $row['id']; // Get the class ID
                      ?>
                      <tr>
                        <td><?php echo $row['name']; ?></td>
                        <td><?php echo $row['username']; ?></td>
                        <td><?php echo $row['password']; ?></td>
                        <td><?php echo $row['role']; ?></td>
                        <td><?php echo $row['phone']; ?></td>
                        <td>
                        <a class="btn btn-info" data-bs-toggle="modal" data-bs-target="#dlModal<?php echo $class_id; ?>">Edit</a>&nbsp;
                          <a class="btn btn-danger" href="employee_delete.php?id=<?php echo $row['id']; ?>" onclick="confirmDelete(event)">Delete</a>
                        </td>
                      </tr>
                   <!-- Modal form -->
      <div class="modal fade" id="dlModal<?php echo $class_id; ?>" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header bg-danger text-white">
              <h5 class="modal-title" id="editModalLabel">Employee Details</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              <!-- Form fields for editing class data -->
              <form action="employee_edit.php" method="post">
                <fieldset>
                  <legend>Edit Employee Details:</legend>
                  <div class="mb-3">
                    <label for="class_name" class="form-label">Name:</label>
                    <input type="text" name="name" id="name" class="form-control" value="<?php echo $row['name']; ?>">
                  </div>
                  <div class="mb-3">
                    <label for="Phone Number" class="form-label">Phone Number:</label>
                    <input type="text" name="phone" id="phone" class="form-control" value="<?php echo $row['phone']; ?>">
                  </div>
                  <div class="mb-3">
                    <label for="Date of Joining" class="form-label">Date of Joining:</label>
                    <input type="text" name="date_of_joining" id="date_of_joining" class="form-control" value="<?php echo $row['date_of_joining']; ?>">
                  </div>
                  <div class="mb-3">
                    <label for="salary" class="form-label">Salary Amount:</label>
                    <input type="text" name="salary_amount" id="salary_amount" class="form-control" value="<?php echo $row['salary_amount']; ?>">
                  </div>
                  <div class="mb-3">
                    <label for="salary_date" class="form-label">Salary Date:</label>
                    <input type="text" name="salary_date" id="salary_date" class="form-control" value="<?php echo $row['salary_date']; ?>">
                  </div>
                    <div class="mb-3">
                    <label for="daily_allowance" class="form-label">Daily Allowance:</label>
                    <input type="text" name="daily_allowance" id="daily_allowance" class="form-control" value="<?php echo $row['daily_allowance']; ?>">
                  </div>
                    <div class="mb-3">
                    <label for="bonus" class="form-label">Bonus:</label>
                    <input type="text" name="bonus" id="bonus" class="form-control" value="<?php echo $row['bonus']; ?>">
                  </div>
                    <div class="mb-3">
                    <label for="working_time" class="form-label">Working Time:</label>
                    <input type="text" name="working_time" id="working_time" class="form-control" value="<?php echo $row['working_time']; ?>">
                  </div>
                   <div class="mb-3">
                    <label for="increment" class="form-label">Increment:</label>
                    <input type="text" name="increment" id="increment" class="form-control" value="<?php echo $row['increment']; ?>">
                  </div>
                  <div class="mb-3">
                    <label for="username" class="form-label">User Name:</label>
                    <input type="text" name="username" id="username" class="form-control" value="<?php echo $row['username']; ?>">
                  </div>
                  <div class="mb-3">
                    <label for="password" class="form-label">Password:</label>
                    <input type="text" name="password" id="password" class="form-control" value="<?php echo $row['password']; ?>">
                  </div>
                  <div class="mb-3">
                    <label for="increment" class="form-label">Previous Role:</label>
                    <input readonly type="text" class="form-control" value="<?php echo $row['role']; ?>">
                    <select class="form-control" id="role" name="role" >
                        <option>Select Role</option>
                        <option value="instructor">Instructor</option>
                        <option value="staff_grade_1">Staff Grade 1</option>
                        <option value="staff_grade_2">Staff Grade 2</option>
                      </select>  
                
                  </div>
                  <input type="hidden" name="class_id" value="<?php echo $class_id; ?>">
                  <input type="submit" value="Update" name="update_staff" class="btn btn-primary">
                </fieldset>
              </form>
            </div>
          </div>
        </div>
      </div>
      <?php
    }
  } else {
    echo "<tr><td colspan='6'>No classes found</td></tr>";
  }
  ?>
                </tbody>
              </table>
            </div>
            <div class="card-footer text-center">
              <a href="employee.php"><button class="button-34">+ Add Employee</button></a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>


<?php
include("admin-footer.php");
?>
<script>
function confirmDelete(event) {
  event.preventDefault(); // Prevent the default behavior of the anchor element

  Swal.fire({
    title: 'Are you sure?',
    text: "You won't be able to revert the Employee Data!",
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#17c1e8',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Yes, delete it!'
  }).then((result) => {
    if (result.isConfirmed) {
      window.location.href = event.target.href; // Proceed with the deletion by redirecting to ad-customer-delete.php
    }
  });
}
</script>