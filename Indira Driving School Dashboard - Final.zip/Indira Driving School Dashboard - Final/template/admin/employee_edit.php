<?php
include("../../connect.php");

if (isset($_POST['update_staff'])) {
    $employee_id = $_POST['class_id'];
    $name = $_POST['name'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $role = $_POST['role'];
    $phone = $_POST['phone'];
    $dateOfJoining = $_POST['date_of_joining'];
    $salaryAmount = $_POST['salary_amount'];
    $salaryDate = $_POST['salary_date'];
    $dailyAllowance = $_POST['daily_allowance'];
    $bonus = $_POST['bonus'];
    $workingTime = $_POST['working_time'];
    $increment = $_POST['increment'];

    // Update staff details in the database
    $sql = "UPDATE staff SET
                name = '$name',
                username = '$username',
                password = '$password',
                role = '$role',
                phone = '$phone',
                date_of_joining = '$dateOfJoining',
                salary_amount = '$salaryAmount',
                salary_date = '$salaryDate',
                daily_allowance = '$dailyAllowance',
                bonus = '$bonus',
                working_time = '$workingTime',
                increment = '$increment'
            WHERE id = '$employee_id'"; // Replace {staff_id} with the actual staff ID to update
    $result = mysqli_query($conn, $sql);
    if ($result) {
        $error = 'Employee details updated successfully!';
        header("Location: employee_list.php?error=" . urlencode($error));
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>
