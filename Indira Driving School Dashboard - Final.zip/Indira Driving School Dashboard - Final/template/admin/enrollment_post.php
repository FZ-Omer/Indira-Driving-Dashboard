<?php
include("../../connect.php");

if (isset($_POST['staff_details'])) {
    // Extract form data
    $enquiry = mysqli_real_escape_string($conn, $_POST['enquiry']);
    $enr_id = mysqli_real_escape_string($conn, $_POST['enrollmentID']);
    $student_name = mysqli_real_escape_string($conn, $_POST['student_name']);
    $father_name = mysqli_real_escape_string($conn, $_POST['father_name']);
    $dob = mysqli_real_escape_string($conn, $_POST['dob']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $referencer = mysqli_real_escape_string($conn, $_POST['referencer']);
    $phoneno = mysqli_real_escape_string($conn, $_POST['phoneno']);
    $blood = mysqli_real_escape_string($conn, $_POST['blood']);
    $point = mysqli_real_escape_string($conn, $_POST['point']);
    $enroll14 = mysqli_real_escape_string($conn, $_POST['enroll14']);
    $llr = mysqli_real_escape_string($conn, $_POST['llr']);
    $validity = mysqli_real_escape_string($conn, $_POST['validity']);
    $package = mysqli_real_escape_string($conn, $_POST['package']);
    $classname = mysqli_real_escape_string($conn, $_POST['classname']);
    $nfd = mysqli_real_escape_string($conn, $_POST['nfd']);
    $fees = mysqli_real_escape_string($conn, $_POST['fees']);
    $working = mysqli_real_escape_string($conn, $_POST['working']);
    $class_time = mysqli_real_escape_string($conn, $_POST['class_time']);
    $photo = $_FILES["photo"]["name"];
    $tempname = $_FILES["photo"]["tmp_name"];
    $folder = "./uploads/" . $photo;

    // Insert data into database
    $query = "INSERT INTO enrollment(enquiry, enr_id, student_name, photo, father_name, dob, address, referencer, phoneno, blood, point, enroll14, llr, validity, package, classname, nfd, fees, working, class_time) 
    VALUES ('$enquiry', '$enr_id', '$student_name', '$photo', '$father_name', '$dob', '$address', '$referencer', '$phoneno', '$blood', '$point', '$enroll14', '$llr', '$validity', '$package', '$classname', '$nfd', '$fees', '$working', '$class_time')";

    $sql = mysqli_query($conn, $query);
    if ($sql) {
        // Move uploaded file to the destination folder
        if (move_uploaded_file($tempname, $folder)) {
            header("Location: enrollment_list.php");
            exit();
        } else {
            echo '<div class="alert alert-danger" role="alert">
                Failed to move uploaded file. Please try again.
            </div>';
        }
    } else {
        echo '<div class="alert alert-danger" role="alert">
            Error occurred while inserting data into the database. Please try again.
        </div>';
    }
} else {
    echo '<div class="alert alert-primary alert-dismissible" role="alert">
        Error! Try Again!
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>';
}

?>