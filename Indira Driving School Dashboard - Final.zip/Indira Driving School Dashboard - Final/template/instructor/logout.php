<?php
// logout.php

session_start();

// Clear all session data
session_unset();
session_destroy();

// Redirect to the login page or any other desired page
header("Location: ../../staff.php");
exit;
?>
