<?php
include("../../connect.php");

// Retrieve the student details from the database
$query = "SELECT id, student_name, nfd,enr_id FROM enrollment";
$result = mysqli_query($conn, $query);

// Retrieve the attendance records from the database
$attendanceQuery = "SELECT student_id, date, status FROM student_attendance";
$attendanceResult = mysqli_query($conn, $attendanceQuery);

// Create an empty attendance array to store the attendance records
$attendanceData = array();

// Loop through the attendance records and store them in the attendance array
if ($attendanceResult && mysqli_num_rows($attendanceResult) > 0) {
  while ($attendanceRow = mysqli_fetch_assoc($attendanceResult)) {
    $studentID = $attendanceRow['student_id'];
    $date = $attendanceRow['date'];
    $status = $attendanceRow['status'];

    // Store the attendance status in the attendance array
    $attendanceData[$studentID][$date] = $status;
  }
}

include("instructor-header.php");
?>

<style>
<style>
  .name-col {
    font-weight: bold;
  }

  .attend-col {
    text-align: center;
  }

  .missed-col {
    font-weight: bold;
    text-align: center;
  }

  thead {
    background-color: #001f3f;
    color: #fff;
    padding: 0.5em 1em;
  }

  td {
    border-top: 1px solid #eee;
    padding: 0.5em 1em;
  }

  .table-responsive {
    overflow-x: auto;
  }

  .present {
    color: green;
    font-weight: bold;
  }

  .absent {
    color: red;
    font-weight: bold;
  }

  table,td,th,tr{
    border: 1px solid black;
    text-align: center;
  }
</style>
</style>

<div class="container-fluid page-body-wrapper">
  <div class="main-panel">
    <div class="content-wrapper">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-md-12">
            <div class="card shadow-sm">
              <div class="card-header bg-danger text-white">
                <h1 class="mb-0">Staff Attendance Details</h1>
              </div>
              <div class="card-body" style="box-shadow: rgba(0, 0, 0, 0.17) 0px -23px 25px 0px inset, rgba(0, 0, 0, 0.15) 0px -36px 30px 0px inset, rgba(0, 0, 0, 0.1) 0px -79px 40px 0px inset, rgba(0, 0, 0, 0.06) 0px 2px 1px, rgba(0, 0, 0, 0.09) 0px 4px 2px, rgba(0, 0, 0, 0.09) 0px 8px 4px, rgba(0, 0, 0, 0.09) 0px 16px 8px, rgba(0, 0, 0, 0.09) 0px 32px 16px;">
                <div class="table-responsive">
                  <table>
                    <thead>
                      <tr>
                        <th class="name-col">Student Name</th>
                        <?php
                        // Generate the table headers for dates
                        $currentMonth = date('m');
                        $currentYear = date('Y');
                        $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $currentMonth, $currentYear);

                        for ($i = 1; $i <= $daysInMonth; $i++) {
                          echo "<th>$i</th>";
                        }
                        ?>
                        <th class="missed-col">Days Missed</th>
                        <th class="missed-col">Total Days</th>
                        <th class="missed-col">Total Present</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                      // Fetch student details from the database
                      if ($result && mysqli_num_rows($result) > 0) {
                        while ($row = mysqli_fetch_assoc($result)) {
                         $studentID = $row['id'];
                           $studentName = $row['student_name'];
                           $totalDays = $row['nfd'];

                          $totalDays = $row['nfd'];
                          echo "<tr class='student'>";
                          echo "<td class='name-col'>$studentName</td>";
                      

                          // Generate attendance cells for each date
                          $presentDays = 0;
                          for ($i = 1; $i <= $daysInMonth; $i++) {
                            $date = date("Y-m-$i");
                            $status = isset($attendanceData[$studentID][$date]) ? $attendanceData[$studentID][$date] : "";
                            $statusClass = ($status == "P") ? "present" : "absent";
                            echo "<td class='attend-col $statusClass'>$status</td>";
                            if ($status == "P") {
                              $presentDays++;
                            }
                          }

                          $absentDays = $daysInMonth - $presentDays;
                          echo "<td class='missed-col'>$absentDays</td>";
                          echo "<td class='missed-col'>$totalDays</td>";
                          echo "<td class='missed-col'>$presentDays</td>";
                          echo "</tr>";
                        }
                      }
                      ?>
                    </tbody>
                  </table>
                </div>
              </div>
              <div class="card-footer text-center">
                <a href="student_attendance_add.php"><button class="btn btn-danger">+ Add Today's Attendance</button></a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php
include("instructor-footer.php");
mysqli_close($conn);
?>
