<?php
include("../../connect.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $studentID = $_POST['enr_id'];

  // Retrieve the student name based on the selected enrollment ID
  $query = "SELECT student_name FROM enrollment WHERE enr_id = '$studentID'";
  $result = mysqli_query($conn, $query);
  $row = mysqli_fetch_assoc($result);
  $studentName = $row['student_name'];

  echo $studentName;
}
?>
