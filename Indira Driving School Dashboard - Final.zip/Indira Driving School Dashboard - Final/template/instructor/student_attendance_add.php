<?php
include("../../connect.php");

// Retrieve the student details from the database
$query = "SELECT id, student_name, enr_id FROM enrollment";
$result = mysqli_query($conn, $query);

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  // Retrieve the attendance data from the form
  $attendanceData = $_POST['attendance'];
  $name = $_POST['name'];

  // Get the current date
  $currentDate = date('Y-m-d');

  // Loop through the attendance data and update the database
  foreach ($attendanceData as $studentID => $attendanceDates) {
    foreach ($attendanceDates as $attendanceDate => $attendanceStatus) {
      // Check if the attendance record already exists for the current date and student
      $query = "SELECT * FROM student_attendance WHERE student_id = '$studentID' AND date = '$attendanceDate'";
      $result = mysqli_query($conn, $query);

      if ($result && mysqli_num_rows($result) > 0) {
        // Attendance record already exists, skip insertion
        continue;
      }

      // Insert the attendance record with the student ID and staff name
      $insertQuery = "INSERT INTO student_attendance (student_id, date, status, staff_name) VALUES ('$studentID', '$attendanceDate', '$attendanceStatus', '$name')";
      mysqli_query($conn, $insertQuery);
    }
  }

  // Redirect back to the attendance page
  header("Location: student_attendance_list.php");
  exit();
}

include("instructor-header.php");
?>

<style>
  thead {
    background-color: #001f3f;
    color: #fff;
    padding: 0.5em 1em;
  }

  td {
    border-top: 1px solid #eee;
    padding: 0.5em 1em;
  }

  .table-responsive {
    overflow-x: auto;
  }
</style>

<div class="container-fluid page-body-wrapper">
  <div class="main-panel">
    <div class="content-wrapper">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-md-8">
            <div class="card shadow-sm">
              <div class="card-header bg-danger text-white">
                <h1 class="mb-0">Student Attendance</h1>
              </div>
              <div class="card-body">
                <div class="table-responsive">
                  <form action="" method="POST">
                    <table class="table table-bordered">
                      <thead>
                        <tr>
                          <th>Enrollment ID</th>
                          <th>Enrollment Name</th>
                          <th>Attendance</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php
                        // Display student details and attendance checkboxes
                        if ($result && mysqli_num_rows($result) > 0) {
                          while ($row = mysqli_fetch_assoc($result)) {
                            $studentID = $row['id'];
                            $studentName = $row['student_name'];
                            ?>
                            <tr>
                              <td><?php echo $studentID; ?></td>
                              <td><?php echo $studentName; ?></td>
                              <td>
                                <select class="form-select" name="attendance[<?php echo $studentID; ?>][<?php echo date('Y-m-d'); ?>]">
                                  <option value="P" <?php if (isset($attendanceData[$studentID][date('Y-m-d')]) && $attendanceData[$studentID][date('Y-m-d')] === 'P') echo 'selected'; ?>>Present</option>
                                  <option value="A" <?php if (isset($attendanceData[$studentID][date('Y-m-d')]) && $attendanceData[$studentID][date('Y-m-d')] === 'A') echo 'selected'; ?>>Absent</option>
                                </select>
                              </td>
                            </tr>
                            <?php
                          }
                        } else {
                          echo '<tr><td colspan="3">No students found.</td></tr>';
                        }
                        ?>
                      </tbody>
                    </table>
                    <input type="hidden" name="name" value="<?php echo $name; ?>">
                    <div class="text-center">
                      <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php
include("instructor-footer.php");
mysqli_close($conn);
?>
Make sure to replace the existing code with this updated version. It should correctly insert the student ID and staff name into the database when submitting the attendance form.
