<?php
extract($_POST);
include("../../connect.php");


$enquiry = $_POST['enquiry'];
$enr_id = $_POST['enrollmentID'];
$existing_student = $_POST['existing_student'];
$student_name = $_POST['student_name'];

$father_name = $_POST['father_name'];
$dob = $_POST['dob'];
$address = $_POST['address'];
$referencer = $_POST['referencer'];
$phoneno = $_POST['phoneno'];
$blood = $_POST['blood'];
$point = $_POST['point'];
$enroll14 = $_POST['enroll14'];
$llr = $_POST['llr'];
$validity = $_POST['validity'];
$package = $_POST['package'];
$classname = $_POST['classname'];
$nfd = $_POST['nfd'];
$fees = $_POST['fees'];
$working = $_POST['working'];
$photo = $_FILES["photo"]["name"];
    $tempname = $_FILES["photo"]["tmp_name"];
    $folder = "./uploads/" . $photo;



if(isset($_POST['staff_details']))


    
{ 
  
  $query = "INSERT INTO enrollment(enquiry, enr_id, existing_student, student_name, photo, father_name, dob, address, referencer, phoneno, blood, point, enroll14, llr, validity, package, classname, nfd, fees, working) 
  VALUES ('$enquiry', '$enr_id', '$existing_student', '$student_name', '$photo', '$father_name', '$dob', '$address', '$referencer', '$phoneno', '$blood', '$point', '$enroll14', '$llr', '$validity', '$package', '$classname', '$nfd', '$fees', '$working')";

        $sql=mysqli_query($conn,$query)or die("Could Not Perform the Query");
        /* If Success */
        if (move_uploaded_file($tempname, $folder)){
        header("Location: enrollment_list.php"); 
       
    }}
    else 
    {
    echo '<div class="alert alert-primary alert-dismissible" role="alert">
        Error ! Try Again !
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>';
  }

?>