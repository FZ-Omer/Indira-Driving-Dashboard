  
<?php
include("staff-header.php");
?>
        
        <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row" >
            
          
           
         
            <div class="col-md-8 grid-margin stretch-card" >
              <div class="card offset-3 " style="box-shadow: rgba(0, 0, 0, 0.56) 0px 22px 70px 4px;">
                <div class="card-header" style="background-color: #c55a0c;">
                    <h1 class="text-white">Discount</h1>
                    
                </div>
                <div class="card-body">
                  <h4 class="card-title">Add Discount Of the Employee</h4>
                  <form action="discount_post" method="post">
                  <div class="row">
                  <div class="col-6 form-group">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text text-white" style="background-color: #631e38;" ><i class="
                          mdi mdi-sort-ascending"></i></span>
                      </div>
                      <input type="text" class="form-control" name="sno" placeholder="S.No" aria-label="Username" >
                    </div>
                  </div>
                  <div class="col-6 form-group">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text text-white" style="background-color: #631e38;"><i class="mdi mdi-human-male"></i></span>
                      </div>
                      <input type="text" class="form-control" name="name"  placeholder="name" aria-label="Name">
                   
                    </div>
                  </div>
                </div>

                <div class="row">
                   
                    <div class="col-6 form-group">
                      <div class="input-group">
                        <div class="input-group-prepend">
                          <span class="input-group-text text-white" style="background-color: #631e38;"><i class="mdi mdi-book-open-page-variant"></i></span>
                        </div>
                        <input type="text" class="form-control" name="classes" placeholder="classes"   required> 
                      </div>
                  </div>

                  <div class="col-6 form-group">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text text-white" style="background-color: #631e38;" ><i class="mdi mdi-calendar-clock"></i></span>
                      </div>
                      <input type="text" class="form-control" name="dfa" placeholder="Date Of Admission" aria-label="Date of Admission">
                    </div>
                  </div>

                  </div>

                  
                  <div class="row">
                
                  <div class="col-6 form-group">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text text-white" style="background-color: #631e38;"><i class="mdi mdi-cash-multiple"></i></span>
                      </div>
                      <input type="text" class="form-control" name="total_amt" placeholder="Total Amount"  required> 
                   
                    </div>
                  </div>


                  <div class="col-6 form-group">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text text-white" style="background-color: #631e38;" ><i class="mdi mdi-currency-inr"></i></span>
                      </div>
                      <input type="text" class="form-control" name="discount_amt" placeholder="Discount Amount" aria-label="Username">
                    </div>
                  </div>
                </div>

                 

                  <h4 class="card-title">Referencer  </h4>
                  
                  <div class="row">
                  <div class="col-6 form-group">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text text-white" style="background-color: #631e38;" ><i class="mdi mdi-account-key"></i></span>
                      </div>
                      <input type="text" class="form-control" name="ref_name" placeholder="Referencer Name" aria-label="REF Name">
                    </div>
                  </div>
                  <div class="col-6 form-group">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text text-white" style="background-color: #631e38;"><i class="mdi mdi-cellphone-iphone"></i></span>
                      </div>
                      <input type="text" class="form-control" name="mobile_no" placeholder="Mobile No" aria-label="Mobile No">
                   
                    </div>
                  </div>
                </div>

             

                 <button type="submit" name="save_discount" class="btn btn-success ">Save</button>
                 <br>
                <a href="discount_list.html"><button class="btn btn-danger">Cancel</button></a> 
              
    
                </div>
              </div>
            </div>
            
           
           
          
          
        
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:../../partials/_footer.html -->
        
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->

<?php
include("staff-footer.php");
?>
  <!-- End custom js for this page-->
  <script>
    // JavaScript code to provide placeholder-like behavior for the date input field
    const dateInput = document.getElementById('date_of_joining');
    dateInput.addEventListener('focus', function() {
      dateInput.type = 'date';
      dateInput.setAttribute('min', '1970-01-01'); // Optional: Set a minimum date if needed
    });
    dateInput.addEventListener('blur', function() {
      if (dateInput.value === '') {
        dateInput.type = 'text';
        dateInput.value = 'date_of_joining';
      }
    });
  </script>
   <script>
    // JavaScript code to provide placeholder-like behavior for the date input field
    const dateInput1 = document.getElementById('salary_date');
    dateInput1.addEventListener('focus', function() {
      dateInput1.type = 'date';
      dateInput1.setAttribute('min', '1970-01-01'); // Optional: Set a minimum date if needed
    });
    dateInput.addEventListener('blur', function() {
      if (dateInput1.value === '') {
        dateInput1.type = 'text';
        dateInput1.value = 'salary_date';
      }
    });
  </script>
</body>

</html>
