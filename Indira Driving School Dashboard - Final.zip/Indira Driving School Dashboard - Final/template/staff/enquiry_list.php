<?php
include("staff-header.php");
?>


<!-- partial -->
<div class="container-fluid page-body-wrapper">
  <div class="main-panel">
    <div class="content-wrapper">
      <div class="row">
        <div class="col-md-8 mx-auto mt-5">
          <div class="card shadow-sm">
            <div class="card-header bg-danger text-white">
              <h1 class="mb-0">Enquiry</h1>
            </div>
            <div class="card-body table-responsive">
              <table id="myTable" class="table table-striped table-bordered">
                <thead>
                  <tr>
                    <th>S.No</th>
                    <th>Student Name</th>
                    <th>Mobile Number</th>
                    <th>Email Id</th>
                    <th>Start Date</th>
                    <th>Time</th>
                    <th>Classes</th>
                    <th>Remarks</th>
                  </tr>
                </thead>
                <tbody>
                  <!-- Add more rows as needed -->
                </tbody>
              </table>
            </div>
          
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php
include("staff-footer.php");
?>
