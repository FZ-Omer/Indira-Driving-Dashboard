<?php

include("../../connect.php");

if (isset($_POST['save_payment'])) {
  $id = $_POST['id'];
  $fees = $_POST['fees'];
  $amount_paid = $_POST['amount_paid'];
  $balance_amount = $_POST['balance_amount'];
  $prev_paid = $_POST['amount_paid'];

  // Retrieve the current value of prev_paid from the database
  $sql_select = "SELECT previous_paid FROM enrollment WHERE id='$id'";
  $result_select = $conn->query($sql_select);
  $row_select = $result_select->fetch_assoc();
  $prev_paid_current = intval($row_select['previous_paid']);
  // Calculate the new value for prev_paid by adding the current amount_paid
  $new_prev_paid = $prev_paid_current + $amount_paid;

  // Update the enrollment table with the new values
  $sql = "UPDATE enrollment SET fees='$fees', amount_paid='$amount_paid', balance_amount='$balance_amount', previous_paid='$new_prev_paid'";

  // Set the status based on the balance_amount value
  if ($balance_amount == 0 || $balance_amount == 0.00) {
    $status = 'Completed';
  } else {
    $status = 'Pending Payment';
  }

  // Append the status to the SQL query
  $sql .= ", status='$status' WHERE id='$id'";

  $result = $conn->query($sql);

  if ($result == TRUE) {
    $error = 'Your Payment Updated Successfully!';
    header("Location: enrollment_list.php?error=" . urlencode($error));
    exit;
  } else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
  }
}


if (isset($_GET['id'])) {

  $id = $_GET['id'];

  $sql = "SELECT * FROM `enrollment` WHERE `id`='$id'";

  $result = $conn->query($sql);

  if ($result->num_rows > 0) {

    while ($row = $result->fetch_assoc()) {

      $id = $row['id'];
      $enr_id = $row['enr_id'];
      $student_name = $row['student_name'];

      $classname = $row['classname'];
      $fees = $row['fees'];
      $prev_paid = $row['previous_paid'];
    }

  }
}

?>
<?php
include("staff-header.php");
?>

<!-- partial -->
<div class="container-fluid page-body-wrapper">
  <div class="main-panel">
    <div class="content-wrapper">
      <div class="row">

        <div class="col-md-8 grid-margin stretch-card">
          <div class="card offset-3 " style="box-shadow: rgba(0, 0, 0, 0.56) 0px 22px 70px 4px;">
            <div class="card-header" style="background-color: #c55a0c;">
              <h1 class="text-white">Payment</h1>

            </div>
            <div class="card-body">
              <h4 class="card-title">Payment Details</h4>
              <form action="" method="post">
                <div class="row">
                  <div class="col-6 form-group">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text text-white" style="background-color: #631e38;"><i
                            class="mdi mdi-account"></i></span>
                      </div>
                      <input value="<?php echo $id ?>" name="id" type="hidden" class="form-control"
                        placeholder="ID" aria-label="ID">
                      <input readonly value="<?php echo $student_name ?>" name="name" type="text" class="form-control"
                        placeholder="Full Name" aria-label="Full name">
                    </div>
                  </div>
                  <div class="col-6 form-group">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text text-white" style="background-color: #631e38;"><i
                            class="mdi mdi-phone-plus"></i></span>
                      </div>
                      <input readonly value="<?php echo $classname ?>" name="class_name" type="text"
                        class="form-control" placeholder="Class Name" aria-label="class_name">

                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-12 form-group">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text text-white" style="background-color: #631e38;"><i
                            class="mdi mdi-calendar-check"></i></span>
                      </div>
                      <input readonly value="<?php echo $fees ?>" type="text" class="form-control" placeholder="Fees"
                        id="fees" name="fees" required>
                    </div>
                  </div>
                </div>

                <h4 class="card-title">Payment Remarks</h4>
                <div class="row">
                  <div class="col-6 form-group">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text text-white" style="background-color: #631e38;"><i
                            class="mdi mdi-cash"></i></span>
                      </div>
                      <input name="amount_paid" type="text" class="form-control" placeholder="Amount Paid"
                        aria-label="paid_amt" oninput="calculateBalance()">
                    </div>
                  </div>
                  <div class="col-6 form-group">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text text-white" style="background-color: #631e38;"><i
                            class="mdi mdi-clipboard-check"></i></span>
                      </div>
                      <input name="balance_amount" type="text" class="form-control" placeholder="Balance Amount"
                        aria-label="bal_amt" readonly>
                    </div>
                  </div>

                  <h4 class="card-title">Previously Paid</h4>
                  <div class="col-6 form-group">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text text-white" style="background-color: #631e38;"><i
                            class="mdi mdi-calculator"></i></span>
                      </div>
                      <input readonly value="<?php echo $prev_paid ?>" type="text" class="form-control"
                        placeholder="Ignore if Not Previously Paid" id="prevPaid" name="previous_paid" required>

                    </div>
                  </div>
                </div>
                <button type="submit" name="save_payment" class="btn btn-success ">Update Payment</button>
              </form>
              <br>
              <a href="payment_list.php"> <button type="button" class="btn btn-danger">Cancel</button></a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- content-wrapper ends -->
    <!-- partial:../../partials/_footer.html -->

    <!-- partial -->
  </div>
  <!-- main-panel ends -->
</div>
<!-- page-body-wrapper ends -->


<?php
include("staff-footer.php");
?>
<!-- End custom js for this page-->
<script>
  // JavaScript code to provide placeholder-like behavior for the date input field
  const dateInput = document.getElementById('date_of_joining');
  dateInput.addEventListener('focus', function () {
    dateInput.type = 'date';
    dateInput.setAttribute('min', '1970-01-01'); // Optional: Set a minimum date if needed
  });
  dateInput.addEventListener('blur', function () {
    if (dateInput.value === '') {
      dateInput.type = 'text';
      dateInput.value = 'date_of_joining';
    }
  });
</script>
<script>
  // JavaScript code to provide placeholder-like behavior for the date input field
  const dateInput1 = document.getElementById('salary_date');
  dateInput1.addEventListener('focus', function () {
    dateInput1.type = 'date';
    dateInput1.setAttribute('min', '1970-01-01'); // Optional: Set a minimum date if needed
  });
  dateInput.addEventListener('blur', function () {
    if (dateInput1.value === '') {
      dateInput1.type = 'text';
      dateInput1.value = 'salary_date';
    }
  });
</script>


<script>
  function calculateBalance() {
    var fees = parseFloat(document.getElementById('fees').value);
    var amountPaid = parseFloat(document.getElementsByName('amount_paid')[0].value);
    var balanceAmount = fees - amountPaid;

    document.getElementsByName('balance_amount')[0].value = balanceAmount.toFixed(2);
  }
</script>