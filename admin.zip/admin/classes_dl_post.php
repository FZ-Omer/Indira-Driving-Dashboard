<?php 
include("../../connect.php");

// Retrieve all classes
$sql = "SELECT * FROM classes_dl";
$result = $conn->query($sql);
?>

<?php
include("../../connect.php");

if (isset($_POST['save_dl'])) {
  $package_name = $_POST['package_name'];
  $fees = $_POST['fees'];
  $simulation = $_POST['simulation'];
  $nfd = $_POST['nfd'];
  $on_road = $_POST['on_road']; // Assuming the column name is 'on_road'
  $theory = $_POST['theory'];
  $reverse = $_POST['reverse'];
  $test_round = $_POST['test_round'];

  $query = "INSERT INTO classes_dl(class_name, fees, simulation, nfd, onroad, theory, reverse, testround) 
            VALUES ('$package_name', '$fees', '$simulation', '$nfd', '$on_road', '$theory', '$reverse', '$test_round')";
  $result = mysqli_query($conn, $query);

  if ($result) {
    header("Location: classes_list.php");
    exit;
  } else {
    echo '<div class="alert alert-danger" role="alert">
            Error! Failed to save the class. Please try again.
          </div>';
  }
}
?>
