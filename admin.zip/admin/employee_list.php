<?php 
include("../../connect.php");
$sql = "SELECT * FROM staff";
$result = $conn->query($sql);
?>

<?php
include("admin-header.php");
?>


<!-- partial -->
<div class="container-fluid page-body-wrapper">
  <div class="main-panel">
    <div class="content-wrapper">
      <div class="row">
        <div class="col-md-8 mx-auto mt-5">
          <div class="card shadow-sm">
            <div class="card-header bg-danger text-white">
              <h1 class="mb-0">Employees</h1>
            </div>
            <div class="card-body table-responsive">
              <table id="myTable" class="table table-striped table-bordered">
                <thead>
                  <tr>
                    <th>Full Name</th>
                    <th>User Name</th>
                    <th>Password</th>
                    <th>Role</th>
                    <th>Phone Number</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                      ?>
                      <tr>
                        <td><?php echo $row['name']; ?></td>
                        <td><?php echo $row['username']; ?></td>
                        <td><?php echo $row['password']; ?></td>
                        <td><?php echo $row['role']; ?></td>
                        <td><?php echo $row['phone']; ?></td>
                        <td>
                          <a class="btn btn-info" href="employee-edit.php?id=<?php echo $row['id']; ?>">Edit</a>&nbsp;
                          <a class="btn btn-danger" href="employee_delete.php?id=<?php echo $row['id']; ?>" onclick="confirmDelete(event)">Delete</a>
                        </td>
                      </tr>
                  <?php
                    }
                  } else {
                    echo "<tr><td colspan='6'>No staff members found</td></tr>";
                  }
                  ?>
                </tbody>
              </table>
            </div>
            <div class="card-footer text-center">
              <a href="employee.php"><button class="button-34">+ Add Employee</button></a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>


<?php
include("admin-footer.php");
?>
<script>
function confirmDelete(event) {
  event.preventDefault(); // Prevent the default behavior of the anchor element

  Swal.fire({
    title: 'Are you sure?',
    text: "You won't be able to revert the Employee Data!",
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#17c1e8',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Yes, delete it!'
  }).then((result) => {
    if (result.isConfirmed) {
      window.location.href = event.target.href; // Proceed with the deletion by redirecting to ad-customer-delete.php
    }
  });
}
</script>