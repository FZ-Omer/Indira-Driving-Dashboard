<?php
// Retrieve the name parameter from the POST data
include("../../connect.php");

$name = $_POST['student_name'];

// Build the SQL query to retrieve the student data for the selected name
$query = "SELECT * FROM enrollment WHERE student_name = '$name'";

// Execute the query and retrieve the result
$result = mysqli_query($conn, $query);

// Retrieve the row from the result as an associative array
if ($result) {
  $student = mysqli_fetch_assoc($result);
  $response = array(
    'id' => $student['id'],
    'student_name' => $student['student_name'],
    'father_name' => $student['father_name'],
    'dob' => $student['dob'],
    'photo' => $student['photo'],
    'address' => $student['address'],
    'referencer' => $student['referencer'],
    'phoneno' => $student['phoneno'],
    'blood' => $student['blood']
    
  );
  echo json_encode($response);
} else {
  echo json_encode(array('error' => 'Database query error.'));
}
?>