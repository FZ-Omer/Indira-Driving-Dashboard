<?php
include("../../connect.php");

// Check if the 'id' parameter is provided in the URL
if(isset($_GET['id'])) {
    // Get the 'id' value from the URL
    $id = $_GET['id'];

    // Update the status to 'Discount Rejected' in the enrollment table
    $sql = "UPDATE enrollment SET status = 'Discount Rejected' WHERE id = $id";

    if(mysqli_query($conn, $sql)) {
        $error = 'Your Discount has Been Rejected!';
          header("Location: enrollment_list.php?error=" . urlencode($error));
          exit;
    } else {
        echo "Error updating status: " . mysqli_error($conn);
    }
} else {
    echo "Invalid request.";
}

// Close the database connection
mysqli_close($conn);
?>
