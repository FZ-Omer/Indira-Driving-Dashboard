
<?php
  include("admin-header.php");
?>

<!-- partial -->
<div class="container-fluid page-body-wrapper">
  <div class="main-panel">
    <div class="content-wrapper">
      <div class="row" >
        <div class="col-md-8 grid-margin stretch-card" >
          <div class="card offset-3 " style="box-shadow: rgba(0, 0, 0, 0.56) 0px 22px 70px 4px;">
            <div class="card-header" style="background-color: #c55a0c;">
              <h1 class="text-white">Classes</h1>
              
            </div>
            <div class="card-body">
              <h4 class="card-title">Add Classes </h4>
              
              <div class="row">
                <div class="col-12 form-group">

                  <label for="package">Classes Package</label>
                  <div class="input-group">
                    <div class="input-group-prepend">
                      <span class="input-group-text text-white" style="background-color: #631e38;"><i class="mdi mdi-contact-mail"></i></span>
                    </div>
                    
                   <select class="form-control" id="package" name="package" aria-placeholder="Select Classes">
                        <option>Select Classes</option>
                        <option value="RC">Registration Certificate</option>
                        <option value="DL">Driving Licence</option>
                  </select>

            
                  </div>
                </div>
              </div>

              <div class="rc-form" >
                <h4 class="card-title">Registration Certificate</h4>
                <form action="classes_rc_post.php" method="post">
                <div class="row">
                <div class="col-6 form-group">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text text-white" style="background-color: #631e38;"><i class="mdi mdi-content-paste"></i></span>
                      </div>
                      <input type="text" class="form-control" placeholder="Class Name" id="className" name="class_name" required> 
                    </div>
                  </div>
                  <div class="col-6 form-group">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text text-white" style="background-color: #631e38;"><i class="mdi mdi-content-paste"></i></span>
                      </div>
                      <input type="text" class="form-control" placeholder="Working" id="working" name="working" required> 
                    </div>
                  </div>
                </div>

                <div class="row">
                  <div class="col-6 form-group">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text text-white" style="background-color: #631e38;"><i class="mdi mdi-credit-card-multiple"></i></span>
                      </div>
                      <input type="text" class="form-control" placeholder="Fees" id="fees" name="fees" required> 
                    </div>
                  </div>

                  <div class="col-6 form-group">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text text-white" style="background-color: #631e38;"><i class="mdi mdi-calendar-check"></i></span>
                      </div>
                      <input type="text" class="form-control" placeholder="No Of Days" id="nfd" name="nfd" required> 
                    </div>
                  </div>
                </div>
                <button type="submit" name="save_rc" class="btn btn-success ">Save RC</button>
                <a href="classes_list.html"> <button class="btn btn-danger">Cancel</button></a>
              </form>
              </div>



              <div class="dl-form" style="display: none;">
                <h4 class="card-title">Driving Licence</h4>

              <form action="classes_dl_post.php" method="post">
                <div class="row">
                  <div class="col-6 form-group">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text text-white" style="background-color: #631e38;"><i class="mdi mdi-human-child"></i></span>
                      </div>
                      <input type="text" class="form-control" placeholder="class Name" id="class_name" name="package_name" required> 
                    </div>
                  </div>

                  <div class="col-6 form-group">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text text-white" style="background-color: #631e38;"><i class="mdi mdi-calendar-check"></i></span>
                      </div>
                      <input type="text" class="form-control" placeholder="No Of Days" id="nfd" name="nfd" required> 
                    </div>
                  </div>


                    <div class="col-6 form-group">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text text-white" style="background-color: #631e38;"><i class="mdi mdi-calendar-check"></i></span>
                      </div>
                      <input type="text" class="form-control" placeholder="Fees" id="fees" name="fees" required> 
                    </div>
                  </div>


                </div>

                <h4 class="card-title">Days of Classes</h4>
                <div class="row">
                  <div class="col-6 form-group">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text text-white" style="background-color: #631e38;"><i class="mdi mdi-map-marker"></i></span>
                      </div>
                      <input type="text" class="form-control" placeholder="Simulation" id="simulation" name="simulation" required> 
                    </div>
                  </div>

                  <div class="col-6 form-group">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text text-white" style="background-color: #631e38;"><i class="mdi mdi-map-marker-circle"></i></span>
                      </div>
                      <input type="text" class="form-control" placeholder="On Road" id="on_road" name="on_road" required> 
                    </div>
                  </div>
                </div>

                <div class="row">
                  <div class="col-6 form-group">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text text-white" style="background-color: #631e38;"><i class="mdi mdi-map-marker-minus"></i></span>
                      </div>
                      <input type="text" class="form-control" placeholder="Theory" id="theory" name="theory" required> 
                    </div>
                  </div>
                  
                  <div class="col-6 form-group">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text text-white" style="background-color: #631e38;"><i class="mdi mdi-map-marker-multiple"></i></span>
                      </div>
                      <input type="text" class="form-control" placeholder="Reverse" id="reverse" name="reverse" required> 
                    </div>
                  </div>
                </div>

                <div class="row">
                  <div class="col-6 form-group">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text text-white" style="background-color: #631e38;"><i class="mdi mdi-map-marker-plus"></i></span>
                      </div>
                      <input type="text" class="form-control" placeholder="Test Round" id="test_round" name="test_round" required> 
                    </div>
                  </div>
                </div>
                
                <button type="submit" name="save_dl" class="btn btn-success ">Save DL</button>
                <a href="classes_list.html"> <button class="btn btn-danger">Cancel</button></a>
              </div>
            </form>


              

              
              
              
            </div>
          </div>
        </div>
        
        
        
        
        
        
      </div>
    </div>
    <!-- content-wrapper ends -->
    <!-- partial:../../partials/_footer.html -->
    <!-- partial -->
  </div>
  <!-- main-panel ends -->
</div>
<!-- page-body-wrapper ends -->

<!-- container-scroller -->
<?php
  include("admin-footer.php");
?>

<script>
  const packageSelect = document.getElementById('package');
  const rcForm = document.querySelector('.rc-form');
  const dlForm = document.querySelector('.dl-form');

  packageSelect.addEventListener('change', function() {
    if (this.value === 'RC') {
      rcForm.style.display = 'block';
      dlForm.style.display = 'none';
    } else if (this.value === 'DL') {
      rcForm.style.display = 'none';
      dlForm.style.display = 'block';
    }
  });
</script>

