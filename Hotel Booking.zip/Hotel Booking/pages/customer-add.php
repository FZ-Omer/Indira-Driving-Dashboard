<!-- Header TAG -->
<?php
include("header-section.php");
?>

<?php
include("../connect.php");
$query2 = "SELECT id, name, phone FROM booking";
$result2 = $conn->query($query2);

if ($result2->num_rows > 0) {
  $customer = mysqli_fetch_all($result2, MYSQLI_ASSOC);

}
?>





<main class="main-content position-relative max-height-vh-100 h-100 mt-1 border-radius-lg ">
    <!-- Navbar -->
    <nav class="navbar navbar-main navbar-expand-lg px-0 mx-4 shadow-none border-radius-xl" id="navbarBlur" navbar-scroll="true">

          <ol class="breadcrumb bg-transparent mb-0 pb-0 pt-1 px-0 me-sm-6 me-5">
            <li class="breadcrumb-item text-sm"><a class="opacity-5 text-dark" href="javascript:;">Staff</a></li>
            <li class="breadcrumb-item text-sm text-dark active" aria-current="page">Booking</li>
          </ol>
          
        </nav>  
          <!-- Content wrapper -->
          <div class="content-wrapper">
            <!-- Content -->

            <div class="container-xxl flex-grow-1 container-p-y">
              <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Booking /</span> New Booking</h4>
              
              <div class="col-md-6">
                <div class="card mb-4">
                  <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Booking Details</h5>
                    
                  </div>
                  <div class="card-body">
                    <form action="customer-details.php" method="post">
                    <div class="mb-3">
                      <div class="form-check form-switch mb-2">
                        <input class="form-check-input" type="checkbox" id="toggleSwitch"  onchange="toggleCustomerDropdown()"/>
                        <label class="form-check-label" for="toggleSwitch">Check For New Customer</label>
                      </div>
                    </div>

                    <div class="mb-3" id="customerDropdown">
                      <label class="form-label" for="basic-icon-default-customer">Existing Customer</label>
                      <div class="input-group input-group-merge">
                        <select id="customerDetails" name="customer_name" class="form-select" onchange="populateCustomerDetails()">
                          <option>Search For Customer Contact</option>
                          <?php
                          foreach ($customer as $full_name) {
                            ?>
                            <option value="<?php echo $full_name['id']; ?>"><?php echo $full_name['phone']; ?> </option>
                            <?php     
                          }
                          ?>
                        </select>
                      </div>
                    </div>

                    <div class="mb-3">
                      <label class="form-label" for="basic-icon-default-fullname">Full Name</label>
                      <div class="input-group input-group-merge">
                        <span id="basic-icon-default-fullname2" class="input-group-text"><i class="fas fa-user"></i></span>
                        <input required type="text" name="name" class="form-control" id="name" placeholder="John Doe" aria-label="John Doe" aria-describedby="basic-icon-default-fullname2" />
                      </div>
                    </div>

                    <div class="mb-3">
                      <label class="form-label" for="basic-icon-default-phone">Phone No</label>
                      <div class="input-group input-group-merge">
                        <span id="basic-icon-default-phone2" class="input-group-text"><i class="fas fa-phone"></i></span>
                        <input required type="text" name="phone" id="phoneNo" class="form-control phone-mask" placeholder="958 799 8941" aria-label="658 799 8941" aria-describedby="basic-icon-default-phone2" />
                      </div>
                    </div>

                      <div class="mb-3">
                        <label class="form-label" for="basic-icon-default-email">Check In Date</label>
                        <div class="input-group input-group-merge">
                          <input
                            type="date"
                            name="checkin_date"
                            id="checkInDate"
                            class="form-control"
                            placeholder=""
                            aria-label="date"
                            aria-describedby="date"
                          />
                        </div>
                      </div>
                      <div class="mb-3">
                        <label class="form-label" for="basic-icon-default-email">Check Out Date</label>
                        <div class="input-group input-group-merge">
                          <input
                            type="date"
                            name="checkout_date"
                            id="checkOutDate"
                            class="form-control"
                            placeholder=""
                            aria-label="date"
                            aria-describedby="date"
                          />
                        </div>
                      </div>

                      <div class="mb-3">
                            <label class="form-label" for="basic-icon-default-phone">Room No</label>
                            <div class="input-group input-group-merge">
                              <span id="basic-icon-default-phone2" class="input-group-text"
                                ><i class="fas fa-bed"></i
                              ></span>
                              <input required
                                type="text"
                                name="room_no"
                                id="roomNo"
                                class="form-control phone-mask"
                                placeholder="Example: 101"
                                aria-label="Employee Password"
                                aria-describedby="basic-icon-default-phone2"
                              />
                            </div>
                          </div>
                      <button name="save" type="submit" class="btn btn-primary">Save Details</button>
                     
                    </form>
                    
                    <a href="customer-list.php"><button  type="submit" class="btn btn-secondary">Cancel</button></a>
                  </div>
                </div>
              </div>
            </div>
            <!-- / Content -->

<!-- ---------------------------SCRIPTS--------------------- -->
<?php
include("footer-section.php");
?>

<script>
  function toggleCustomerDropdown() {
    var toggleSwitch = document.getElementById("toggleSwitch");
    var customerDropdown = document.getElementById("customerDropdown");

    if (toggleSwitch.checked) {
      customerDropdown.style.display = "none";
      customerDropdown.querySelector("select").disabled = true;
    } else {
      customerDropdown.style.display = "block";
      customerDropdown.querySelector("select").disabled = false;
    }
  }
</script>

<script>
function populateCustomerDetails() {
  var selectElement = document.getElementById("customerDetails");
  var selectedCustomerId = selectElement.value;
  var fullNameInput = document.getElementById("name");
  var phoneInput = document.getElementById("phoneNo");

  // Make an AJAX request to fetch customer data
  var xhr = new XMLHttpRequest();
  xhr.onreadystatechange = function() {
    if (xhr.readyState === 4 && xhr.status === 200) {
      var customerData = JSON.parse(xhr.responseText);

      // Populate the full name and phone number inputs
      fullNameInput.value = customerData.name;
      phoneInput.value = customerData.phone;
    }
  };

  // Set up the request URL
  var url = "../admin/ad-fetch-customer.php?id=" + selectedCustomerId;

  // Send the AJAX request
  xhr.open("GET", url, true);
  xhr.send();
}

</script>
  </body>
</html>