<!-- Auto Generation of number -->
<?php
include '../connect.php';
$query2 = "SELECT invoice_no from invoice order by id desc limit 1";
$result2 = mysqli_query($conn, $query2);

if ($result2 && mysqli_num_rows($result2) > 0) {
  $row = mysqli_fetch_array($result2);
  $last_id = $row['invoice_no'];
} else {
  $last_id = "";
}

if ($last_id === "") {
  $customer_ID = "INV0001";
} else {
  $customer_ID = substr($last_id, 6);
  $customer_ID = intval($customer_ID);
  $customer_ID = "INV" . sprintf('%04d', $customer_ID + 1);
}
?>

<?php
$query3 = "SELECT * FROM room";
$result3 = $conn->query($query3);

if ($result3->num_rows > 0) {
  $product_sale = mysqli_fetch_all($result3, MYSQLI_ASSOC);

}
?>

<?php
$query1 = "SELECT * FROM employees";
$result1 = $conn->query($query1);

if ($result1->num_rows > 0) {
  $employees = mysqli_fetch_all($result1, MYSQLI_ASSOC);

}
?>
<?php
$query2 = "SELECT * FROM booking WHERE checkout_date = CURDATE()";
$result2 = $conn->query($query2);

if ($result2->num_rows > 0) {
  $room_no = mysqli_fetch_all($result2, MYSQLI_ASSOC);
}
?>


<!-- Header TAG -->
<?php
include("header-section.php");
?>

<main class="main-content position-relative max-height-vh-100 h-100 mt-1 border-radius-lg ">
    <!-- Navbar -->
    <nav class="navbar navbar-main navbar-expand-lg px-0 mx-4 shadow-none border-radius-xl" id="navbarBlur" navbar-scroll="true">

          <ol class="breadcrumb bg-transparent mb-0 pb-0 pt-1 px-0 me-sm-6 me-5">
            <li class="breadcrumb-item text-sm"><a class="opacity-5 text-dark" href="javascript:;">Staff</a></li>
            <li class="breadcrumb-item text-sm text-dark active" aria-current="page">Add Invoice</li>
          </ol>
          
        </nav>  

          <!-- Content wrapper -->
          <div class="content-wrapper">
            <!-- Content -->

            <div class="container-xxl flex-grow-1 container-p-y">
              <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">INVOICE /</span> New Invoice</h4>
              
              <div class="row">
              <form action="invoice_post.php" method="POST">
                <div class="col-md-8">
                  <div class="card mb-4">
                    <h5 class="card-header">Room Details</h5>
                    <div class="card-body">
                    

                    <div id="existingCustomerFields" class="customer-fields">
                      <!-- Customer fields -->
                      <select id="customerDetails" name="room_no" class="form-select" onchange="fetchData()">
                        <option>Search for Today's Check Out Rooms</option>
                        <?php
                        foreach ($room_no as $full_name) {
                          echo '<option value="' . $full_name['room_no'] . '">' . $full_name['room_no'] . '</option>';
                        }
                        ?>
                      </select>
                      <br>
                    </div>
                <!-- New customer fields -->
                <div class="mb-3">
                  <label class="form-label" for="basic-icon-default-fullname">Full Name</label>
                  <div class="input-group input-group-merge">
                    <span class="input-group-text">
                      <i class="bx bx-user"></i>
                    </span>
                    <input readonly name="customer_name" type="text" class="form-control" id="bookingName" placeholder="John Doe" aria-label="John Doe" aria-describedby="basic-icon-default-fullname2" />
                  </div>
                </div>

                <div class="mb-3">
                  <label class="form-label" for="basic-icon-default-phone">Phone No</label>
                  <div class="input-group input-group-merge">
                    <span class="input-group-text">
                      <i class="bx bx-phone"></i>
                    </span>
                    <input readonly name="customer_phone" type="text" id="bookingPhone" class="form-control phone-mask" placeholder="658 799 8941" aria-label="658 799 8941" aria-describedby="basic-icon-default-phone2" />
                  </div>
                  </div>
                  <div class="mb-3">
                  <label class="form-label" for="basic-icon-default-phone">Room Type</label>
                  <div class="input-group input-group-merge">
                    <span class="input-group-text">
                      <i class="bx bx-phone"></i>
                    </span>
                    <input readonly name="room_type" type="text" id="roomType" class="form-control phone-mask" placeholder="Example: Suite" aria-label="Room Type" aria-describedby="basic-icon-default-phone2" />
                  </div>
                  </div>
                  <div class="mb-3">
                  <label class="form-label" for="basic-icon-default-phone">Ac / Non AC</label>
                  <div class="input-group input-group-merge">
                    <span class="input-group-text">
                      <i class="bx bx-phone"></i>
                    </span>
                    <input readonly name="ac_nonac" type="text" id="acNonac" class="form-control phone-mask" placeholder="Example: AC" aria-label="Ac / Non Ac" aria-describedby="basic-icon-default-phone2" />
                  </div>
                  </div>
                  <div class="mb-3">
                  <label class="form-label" for="basic-icon-default-phone">Meals</label>
                  <div class="input-group input-group-merge">
                    <span class="input-group-text">
                      <i class="bx bx-phone"></i>
                    </span>
                    <input readonly name="had_meals" type="text" id="roomMeals" class="form-control phone-mask" placeholder="Example: Lunch" aria-label="Meals" aria-describedby="basic-icon-default-phone2" />
                  </div>
                  </div>
                  <div class="mb-3">
                  <label class="form-label" for="basic-icon-default-phone">Meals Cost</label>
                  <div class="input-group input-group-merge">
                    <span class="input-group-text">
                      <i class="bx bx-phone"></i>
                    </span>
                    <input required name="meals_cost" type="text" id="mealsCost" class="form-control phone-mask" placeholder="Example: 1000" aria-label="meals price" aria-describedby="basic-icon-default-phone2" />
                  </div>
                  </div>
                  <div class="mb-3">
                  <label class="form-label" for="basic-icon-default-phone">Rent</label>
                  <div class="input-group input-group-merge">
                    <span class="input-group-text">
                      <i class="bx bx-phone"></i>
                    </span>
                    <input readonly name="room_rent" type="text" id="roomRent" class="form-control phone-mask" placeholder="Example: 5000" aria-label="rent" aria-describedby="basic-icon-default-phone2" />
                  </div>
                  </div>

                <div class="mb-3">
                  <label class="form-label" for="basic-icon-default-phone">Check In Date</label>
                  <div class="input-group input-group-merge">
                    <span class="input-group-text">
                      <i class="bx bx-phone"></i>
                    </span>
                    <input readonly name="checkin_date" type="text" id="checkInDate" class="form-control phone-mask" placeholder="Check In Date" aria-label="Check In Date" aria-describedby="basic-icon-default-phone2" />
                  </div>
                </div>
                             
              <div class="mb-3">
                  <label class="form-label" for="basic-icon-default-phone">Check Out Date</label>
                  <div class="input-group input-group-merge">
                    <span class="input-group-text">
                      <i class="bx bx-phone"></i>
                    </span>
                    <input readonly name="checkout_date" type="text" id="checkOutDate" class="form-control phone-mask" placeholder="Check Out Date" aria-label="Check Out Date" aria-describedby="basic-icon-default-phone2" />
                  </div>
                </div>
            </div>
            </div>
                
                <div class="row">
                <div class="container-xxl flex-grow-1 container-p-y">
                    <div class="col-xl-12">
                        <!-- HTML5 Inputs -->
                        <div class="card mb-4">
                          <h5 class="card-header">Invoice Details</h5>
                          <div class="card-body">
                            <div class="mb-3 row">
                              <label for="html5-text-input" class="col-md-2 col-form-label">Invoice#</label>
                              <div class="col-md-10">
                              <input type="text" class="form-control" name="invoice_no" id="invoice_id" value="<?php echo $customer_ID; ?>" readonly>
                              </div>
                            </div>
                          
                            
                            <div class="mb-3 row">
                                <label for="html5-text-input" class="col-md-2 col-form-label">Employees</label>
                                <div class="col-md-10">
                                    <select id="defaultSelect" name="employee_name" class="form-select">
                                    <option>Select Employee name</option>
                                        <!-- This Code Fetches and Displays 'name' Data From 'tme' DB -->
                                        <?php
                                        foreach ($employees as $saleoption) {
                                          ?>
                                            <option><?php echo $saleoption['name']; ?> </option>
                                            <?php
                                        }
                                        ?>
                                      </select>
                                </div>
                              </div>
                          
                              <div class="mb-3 row">
                              <label for="html5-date-input" class="col-md-4 col-form-label">Extra Bed Charges</label>
                              <div class="col-md-10">
                                <input required class="form-control" name="extra_bed" type="text" placeholder="Example: 1000" id="extraBedCharges" />
                                
                              </div>
                              
                            </div>
                            <div class="mb-3 row">
                                <label for="html5-date-input" class="col-md-4 col-form-label">Sub Total</label>
                                <div class="col-md-10">
                                    <input readonly class="form-control" name="sub_total" type="text" placeholder="Sub Total" id="subTotal" />
                                </div>
                            </div>
                            <div class="mb-3 row">
                                  <label for="gst_value" class="col-md-2 col-form-label">GST</label>
                                  <div class="col-md-10">
                                      <select id="gstValue" name="gst_value" class="form-select">
                                          <option>Select GST Value</option>
                                          <option value="5">5%</option>
                                          <option value="12">12%</option>
                                          <option value="18">18%</option>
                                          <option value="28">28%</option>
                                      </select>
                                  </div>
                              </div>

                              <div class="mb-3 row">
                                <label for="grand_total" class="col-md-4 col-form-label">Grand Total</label>
                                <div class="col-md-10">
                                    <input readonly class="form-control" name="grand_total" type="text" placeholder="Grand Total" id="grandTotal" />
                                </div>
                            </div>
                          </div>
                        </div> 
                        </div>
            <button  type="submit" name="save_invoice" class="btn btn-primary">Save & Send</button>
            <br>
            </form>
           
            <a href="dashboard.php"><button type="button"  class="btn btn-secondary">Cancel</button></a>
          </div>
          </div>
           
      </div>
            <!-- / Content -->
            
<!-- Footer TAG -->
<?php
include("footer-section.php");
?>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- Room Rent Calculation -->
<script>
    // Get the necessary elements
    const checkInDateInput = document.getElementById('checkInDate');
    const checkOutDateInput = document.getElementById('checkOutDate');
    const roomRentInput = document.getElementById('roomRent');
    const mealsCostInput = document.getElementById('mealsCost');
    const extraBedChargesInput = document.getElementById('extraBedCharges');
    const subTotalInput = document.getElementById('subTotal');
    const gstValueSelect = document.getElementById('gstValue');
    const grandTotalInput = document.getElementById('grandTotal');

    // Function to calculate the number of days between two dates
    function calculateNumberOfDays(checkInDate, checkOutDate) {
        const oneDay = 24 * 60 * 60 * 1000; // One day in milliseconds
        const firstDate = new Date(checkInDate);
        const secondDate = new Date(checkOutDate);
        const numberOfDays = Math.round(Math.abs((firstDate - secondDate) / oneDay));
        return numberOfDays;
    }

    // Function to calculate the subtotal
    function calculateSubTotal() {
        const checkInDate = checkInDateInput.value;
        const checkOutDate = checkOutDateInput.value;
        const roomRent = parseFloat(roomRentInput.value);
        const mealsCost = parseFloat(mealsCostInput.value);
        const extraBedCharges = parseFloat(extraBedChargesInput.value);

        if (!isNaN(roomRent) && checkInDate && checkOutDate) {
            const numberOfDays = calculateNumberOfDays(checkInDate, checkOutDate);
            let subTotal = roomRent * numberOfDays;

            if (!isNaN(mealsCost)) {
                subTotal += mealsCost;
            }

            if (!isNaN(extraBedCharges)) {
                subTotal += extraBedCharges;
            }

            subTotalInput.value = subTotal.toFixed(2);
            calculateGrandTotal(); // Call calculateGrandTotal after updating subTotal
        } else {
            subTotalInput.value = "";
            grandTotalInput.value = ""; // Reset grandTotal if subTotal is empty
        }
    }

    // Function to calculate and update the grand total
    function calculateGrandTotal() {
        const gstValue = parseFloat(gstValueSelect.value);
        const subTotal = parseFloat(subTotalInput.value);
        const grandTotal = subTotal + (subTotal * (gstValue / 100));

        grandTotalInput.value = grandTotal.toFixed(2);
    }

    // Event listeners to trigger the calculations
    checkInDateInput.addEventListener('input', calculateSubTotal);
    checkOutDateInput.addEventListener('input', calculateSubTotal);
    roomRentInput.addEventListener('input', calculateSubTotal);
    mealsCostInput.addEventListener('input', calculateSubTotal);
    extraBedChargesInput.addEventListener('input', calculateSubTotal);
    gstValueSelect.addEventListener('change', calculateGrandTotal);

    // Initial calculation on page load (if needed)
    calculateSubTotal();
</script>


<script>
function fetchData() {
  fetchCustomerDetails();
  fetchRoomDetails();
}

function fetchCustomerDetails() {
  var roomNo = document.getElementById('customerDetails').value;
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      var customerDetails = JSON.parse(this.responseText);
      document.getElementById('bookingName').value = customerDetails.name;
      document.getElementById('bookingPhone').value = customerDetails.phone;
      document.getElementById('checkInDate').value = customerDetails.checkin_date;
      document.getElementById('checkOutDate').value = customerDetails.checkout_date;
    }
  };
  xhttp.open('GET', '../admin/invoice-customer-fetch.php?room_no=' + roomNo, true);
  xhttp.send();
}

function fetchRoomDetails() {
  var roomNo = document.getElementById('customerDetails').value;
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      var roomDetails = JSON.parse(this.responseText);
      document.getElementById('roomType').value = roomDetails.room_type;
      document.getElementById('roomMeals').value = roomDetails.meal;
      document.getElementById('roomRent').value = roomDetails.rent;
      document.getElementById('acNonac').value = roomDetails.ac_nonac;
    }
  };
  xhttp.open('GET', '../admin/invoice-room-fetch.php?room_no=' + roomNo, true);
  xhttp.send();
}
</script>
    
</body>
</html>