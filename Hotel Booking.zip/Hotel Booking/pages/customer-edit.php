<?php 

include("../connect.php");

if (isset($_POST['update_booking'])) {
  $id = $_POST['id']; 
  $name = $_POST['name'];
  $room_no = $_POST['room_no'];
  $phone = $_POST['phone'];
  $checkin_date = $_POST['checkin_date'];
  $checkout_date = $_POST['checkout_date'];

  $sql = "UPDATE `booking` SET `name`='$name', `room_no`='$room_no', `phone`='$phone', `checkin_date`='$checkin_date', `checkout_date`='$checkout_date'  WHERE `id`='$id'";
  $result = $conn->query($sql);

  if ($result == TRUE) {
    // Update the status column in the room table
    $roomStatusSql = "UPDATE `room` SET `status`='Booked' WHERE `room_no`='$room_no'";
    $roomStatusResult = $conn->query($roomStatusSql);

    if ($roomStatusResult == TRUE) {
      $error = 'Your Booking Details Updated Successfully!';
      header("Location: customer-list.php?error=" . urlencode($error));
      exit;
    } else {
      echo "Error updating room status: " . $conn->mysqli_error($conn);
    }
  } else {
    echo "Error updating booking details: " . $conn->mysqli_error($conn);
  }
}


    

    if (isset($_GET['id'])) {
    
        $id = $_GET['id']; 
    
        $sql = "SELECT * FROM `booking` WHERE `id`='$id'";
    
        $result = $conn->query($sql); 
    
        if ($result->num_rows > 0) {        
    
            while ($row = $result->fetch_assoc()) {
    
            $id = $row['id'];
            $name = $row['name'];
            $phone = $row['phone'];
            $checkin_date = $row['checkin_date'];
            $checkout_date = $row['checkout_date'];
            $room_no = $row['room_no'];
            } 
    
          }
        }

    ?>

<!-- Header TAG -->
<?php
include("header-section.php");
?>
<main class="main-content position-relative max-height-vh-100 h-100 mt-1 border-radius-lg ">
    <!-- Navbar -->
    <nav class="navbar navbar-main navbar-expand-lg px-0 mx-4 shadow-none border-radius-xl" id="navbarBlur" navbar-scroll="true">

          <ol class="breadcrumb bg-transparent mb-0 pb-0 pt-1 px-0 me-sm-6 me-5">
            <li class="breadcrumb-item text-sm"><a class="opacity-5 text-dark" href="javascript:;">Staff</a></li>
            <li class="breadcrumb-item text-sm text-dark active" aria-current="page">Edit Booking</li>
          </ol>
          
        </nav> 
                 <!-- Content wrapper -->
                 <div class="content-wrapper">
            <!-- Content -->

            <div class="container-xxl flex-grow-1 container-p-y">
              <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Booking /</span> Edit Booking</h4>
              
              <div class="col-md-6">
                <div class="card mb-4">
                  <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Employees details</h5>
                    
                  </div>
                  <div class="card-body">
                    <form action="" method="post">
                    <input
                            name="id"
                            type="hidden"
                            value="<?php echo $id ?>"
                            class="form-control"
                            id=""
                            placeholder="John Doe"
                            aria-label="John Doe"
                            aria-describedby=""
                          />
                    <div class="mb-3">
                      <label class="form-label" for="basic-icon-default-fullname">Full Name</label>
                      <div class="input-group input-group-merge">
                      
                        <span id="basic-icon-default-fullname2" class="input-group-text"><i class="fas fa-user"></i></span>
                        <input readonly value="<?php echo $name ?>" type="text" name="name" class="form-control" id="name"  aria-label="John Doe" aria-describedby="basic-icon-default-fullname2" />
                        
                      </div>
                    </div>

                    <div class="mb-3">
                      <label class="form-label" for="basic-icon-default-phone">Phone No</label>
                      <div class="input-group input-group-merge">
                        <span id="basic-icon-default-phone2" class="input-group-text"><i class="fas fa-phone"></i></span>
                        <input readonly value="<?php echo $phone ?>" type="text" name="phone" id="phoneNo" class="form-control phone-mask"  aria-label="658 799 8941" aria-describedby="basic-icon-default-phone2" />
                      </div>
                    </div>

                      <div class="mb-3">
                        <label class="form-label" for="basic-icon-default-email">Check In Date</label>
                        <div class="input-group input-group-merge">
                        
                          <input readonly
                            value="<?php echo $checkin_date ?>"
                            type="date"
                            name="checkin_date"
                            id="checkInDate"
                            class="form-control"
                            placeholder=""
                            aria-label="date"
                            aria-describedby="date"
                          />
                        </div>
                      </div>
                      <div class="mb-3">
                        <label class="form-label" for="basic-icon-default-email">Check Out Date</label>
                        <div class="input-group input-group-merge">
                          <input required
                            value="<?php echo $checkout_date ?>"
                            type="date"
                            name="checkout_date"
                            id="checkOutDate"
                            class="form-control"
                            placeholder=""
                            aria-label="date"
                            aria-describedby="date"
                          />
                        </div>
                      </div>

                      <div class="mb-3">
                            <label class="form-label" for="basic-icon-default-phone">Room No</label>
                            <div class="input-group input-group-merge">
                              <span id="basic-icon-default-phone2" class="input-group-text"
                                ><i class="fas fa-bed"></i
                              ></span>
                              <input required
                                value="<?php echo $room_no ?>"
                                type="text"
                                name="room_no"
                                id="roomNo"
                                class="form-control phone-mask"
                                placeholder="Example: 101"
                                aria-label="Employee Password"
                                aria-describedby="basic-icon-default-phone2"
                              />
                            </div>
                          </div>
                      <button name="update_booking" type="submit" class="btn btn-primary">Save Details</button>
                     
                    </form>
                   
                    <a href="customer-list.php"><button  type="submit" class="btn btn-secondary">Cancel</button></a>
                  </div>
                </div>
              </div>
            </div>
            <!-- / Content -->

            <?php
include("footer-section.php");
?>
  </body>
</html>