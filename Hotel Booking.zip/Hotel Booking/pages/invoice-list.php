<?php
include("../connect.php");

// Check if date range is provided
if (isset($_POST['from_date']) && isset($_POST['to_date'])) {
  $from_date = $_POST['from_date'];
  $to_date = $_POST['to_date'];
  $sql = "SELECT * FROM invoice  WHERE checkout_date BETWEEN '$from_date' AND '$to_date' ORDER BY checkout_date DESC";
} else {
  // If date range is not provided, fetch all records
  $sql = "SELECT * FROM invoice GROUP BY invoice_no ORDER BY checkout_date DESC";
}

$result = $conn->query($sql);

// Check if reset filter button is clicked
if (isset($_POST['reset_filter'])) {
  // Redirect back to same page
  header("Location: ".$_SERVER['PHP_SELF']);
  exit;
}
?>

<!-- Header TAG -->
<?php
include("header-section.php");
?>

<main class="main-content position-relative max-height-vh-100 h-100 mt-1 border-radius-lg ">
    <!-- Navbar -->
    <nav class="navbar navbar-main navbar-expand-lg px-0 mx-4 shadow-none border-radius-xl" id="navbarBlur" navbar-scroll="true">

          <ol class="breadcrumb bg-transparent mb-0 pb-0 pt-1 px-0 me-sm-6 me-5">
            <li class="breadcrumb-item text-sm"><a class="opacity-5 text-dark" href="javascript:;">Staff</a></li>
            <li class="breadcrumb-item text-sm text-dark active" aria-current="page">Invoice</li>
          </ol>
          
        </nav>

<!-- Content wrapper -->
<div class="content-wrapper">

  <div class="container-xxl flex-grow-1 container-p-y">
  <?php
                   if(isset($_GET['error'])) {
                    $error = $_GET['error'];
                    echo '<div class="alert alert-success alert-dismissible" role="alert">
                    ' . $error . '
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                      </div>'; 
                     }
                ?>

    
    <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">REPORT /</span> INVOICE Report</h4>
    <a href="invoice.php"><button class="btn btn-success">Add Invoice</button></a>
    <!-- Date range filter form -->
    <form method="post">
      <div class="row mb-3">
        <div class="col-md-4">
          <label for="from_date" class="form-label">From Date</label>
          <input type="date" class="form-control" id="from_date" name="from_date">
        </div>
        <div class="col-md-4">
          <label for="to_date" class="form-label">To Date</label>
          <input type="date" class="form-control" id="to_date" name="to_date">
        </div>
        <div class="col-md-4 mt-4">
          <button type="submit" class="btn btn-primary">Filter</button>
          <button type="submit" class="btn btn-secondary" name="reset_filter">Reset Filter</button>
        </div>
      </div>
    </form>

    <div class="table-responsive">
      <table id="example" class="table table-striped table-bordered">
      <thead>

  <tr>
    <th style="background-color: #f2f2f2; color: #444444;">Invoice No</th>
    <th style="background-color: #f2f2f2; color: #444444;">Check-in Date</th>
    <th style="background-color: #f2f2f2; color: #444444;">Check-out Date</th>
    <th style="background-color: #f2f2f2; color: #444444;">Customer Name</th>
    <th style="background-color: #f2f2f2; color: #444444;">Customer Phone</th>
    <th style="background-color: #f2f2f2; color: #444444;">Room No</th>
    <th style="background-color: #f2f2f2; color: #444444;">Room Type</th>
    <th style="background-color: #f2f2f2; color: #444444;">AC/Non-AC</th>
    <th style="background-color: #f2f2f2; color: #444444;">Had Meals</th>
    <th style="background-color: #f2f2f2; color: #444444;">Meals Cost</th>
    <th style="background-color: #f2f2f2; color: #444444;">Room Rent</th>
    <th style="background-color: #f2f2f2; color: #444444;">Employee Name</th>
    <th style="background-color: #f2f2f2; color: #444444;">Extra Bed</th>
    <th style="background-color: #f2f2f2; color: #444444;">GST Value</th>
    <th style="background-color: #f2f2f2; color: #444444;">Sub Total</th>
    <th style="background-color: #f2f2f2; color: #444444;">Grand Total</th>
    <th>Action</th> <!-- Empty header for the "Print" column -->
  </tr>


</thead>
        <tbody>
          <?php
          if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
          ?>
              <tr>
              <td><?php echo $row['invoice_no']; ?></td>
              <td><?php echo $row['checkin_date']; ?></td>
              <td><?php echo $row['checkout_date']; ?></td>
              <td><?php echo $row['customer_name']; ?></td>
              <td><?php echo $row['customer_phone']; ?></td>
              <td><?php echo $row['room_no']; ?></td>
              <td><?php echo $row['room_type']; ?></td>
              <td><?php echo $row['ac_nonac']; ?></td>
              <td><?php echo $row['had_meals']; ?></td>
              <td><?php echo $row['meals_cost']; ?></td>
              <td><?php echo $row['room_rent']; ?></td>
              <td><?php echo $row['employee_name']; ?></td>
              <td><?php echo $row['extra_bed']; ?></td>
              <td><?php echo $row['gst_value']; ?></td>
              <td><?php echo $row['sub_total']; ?></td>
              <td><?php echo $row['grand_total']; ?></td>
              <td><a class="btn btn-info rounded-pill bx bxs-printer" href="invoice-creation.php?id=<?php echo $row['invoice_no']; ?>"> Print</a></td>
              </tr>
          <?php
            }
          }
          ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<!-- Content -->

<!-- Header TAG -->
<?php
include("footer-section.php");
?>