

<style>
        .box-buldge-shadow{
          box-shadow: rgba(0, 0, 0, 0.17) 0px -23px 25px 0px inset, rgba(0, 0, 0, 0.15) 0px -36px 30px 0px inset, rgba(0, 0, 0, 0.1) 0px -79px 40px 0px inset, rgba(0, 0, 0, 0.06) 0px 2px 1px, rgba(0, 0, 0, 0.09) 0px 4px 2px, rgba(0, 0, 0, 0.09) 0px 8px 4px, rgba(0, 0, 0, 0.09) 0px 16px 8px, rgba(0, 0, 0, 0.09) 0px 32px 16px;
          border-radius: 20px;
        }

        .room-box {
            width: 180px;
            height: 200px;
            border: 1px solid black;
            border-top-left-radius: 40%;
            border-bottom-right-radius: 37%;
            margin: 10px;
            text-align: center;
            color: White;
            display: flex;
            flex-direction: column;
            justify-content: center;
            box-shadow: rgba(0, 0, 0, 0.17) 0px -23px 25px 0px inset, rgba(0, 0, 0, 0.15) 0px -36px 30px 0px inset, rgba(0, 0, 0, 0.1) 0px -79px 40px 0px inset, rgba(0, 0, 0, 0.06) 0px 2px 1px, rgba(0, 0, 0, 0.09) 0px 4px 2px, rgba(0, 0, 0, 0.09) 0px 8px 4px, rgba(0, 0, 0, 0.09) 0px 16px 8px, rgba(0, 0, 0, 0.09) 0px 32px 16px;
           
        }

        .booked {
          background: linear-gradient(45deg, #B105B1, #F50B88) !important;
        }

        .available {
          background: linear-gradient(120deg, #A6D0DD, #003A70) !important;
        }
</style>

<!-- Header TAG -->
<?php
include("header-section.php");
?>
<!-- -------------CURRENT DATE TOTAL ---------------------- -->
<?php
//  Database connection established
include("../connect.php");

// Get the current date
$currentDate = date('Y-m-d');

// Query to calculate the sum of grand_total
$query = "SELECT SUM(grand_total) AS total FROM invoice WHERE checkout_date = '$currentDate'";

// Execute the query
$result = mysqli_query($conn, $query);

// Check if the query was successful
if ($result) {
  // Fetch the total value
  $row = mysqli_fetch_assoc($result);
  $total = $row['total'];
} else {
  // Query execution failed
  $total = 0; // Set a default value or handle the error
}

// Close the database connection
mysqli_close($conn);
?>
<!-- -------------CURRENT DATE CHECK IN's ---------------------- -->
<?php
// Assuming you have a database connection established
include("../connect.php");
// Get the current date
$currentDate = date('Y-m-d');

// Query to count the number of customers checked-in
$query = "SELECT COUNT(*) AS today_booking FROM booking WHERE checkin_date = '$currentDate'";

// Execute the query
$result = mysqli_query($conn, $query);

// Check if the query was successful
if ($result) {
  // Fetch the today_booking value
  $row = mysqli_fetch_assoc($result);
  $today_booking = $row['today_booking'];
} else {
  // Query execution failed
  $today_booking = 0; // Set a default value or handle the error
}

// Close the database connection
mysqli_close($conn);
?>
<!-- -------------CURRENT MONTH CHECK OUTS ---------------------- -->
<?php
// Assuming you have a database connection established
include("../connect.php");

// Get the current month and year
$currentMonth = date('m');
$currentYear = date('Y');

// Query to count the total checkouts for the current month
$query = "SELECT COUNT(DISTINCT checkout_date) AS total_checkout FROM invoice WHERE MONTH(checkout_date) = $currentMonth AND YEAR(checkout_date) = $currentYear";

// Execute the query
$result = mysqli_query($conn, $query);

// Check if the query was successful
if ($result) {
  // Fetch the total_checkout value
  $row = mysqli_fetch_assoc($result);
  $total_checkout = $row['total_checkout'];
} else {
  // Query execution failed
  $total_checkout = 0; // Set a default value or handle the error
}

// Close the database connection
mysqli_close($conn);
?>
<!-- -------------CURRENT MONTH TOTAL ---------------------- -->
<?php
// Assuming you have a database connection established
include("../connect.php");

// Get the current month and year
$currentMonth = date('m');
$currentYear = date('Y');

// Query to count the total checkouts for the current month
$query = "SELECT  SUM(grand_total) AS month_total FROM invoice WHERE MONTH(checkout_date) = $currentMonth AND YEAR(checkout_date) = $currentYear";

// Execute the query
$result = mysqli_query($conn, $query);

// Check if the query was successful
if ($result) {
  // Fetch the month_total value
  $row = mysqli_fetch_assoc($result);
  $month_total = $row['month_total'];
} else {
  // Query execution failed
  $month_total = 0; // Set a default value or handle the error
}

// Close the database connection
mysqli_close($conn);
?>
<main class="main-content position-relative max-height-vh-100 h-100 mt-1 border-radius-lg">
    <!-- Navbar -->
    <nav class="navbar navbar-main navbar-expand-lg px-0 mx-4 shadow-none border-radius-xl" id="navbarBlur" navbar-scroll="true">

          <ol class="breadcrumb bg-transparent mb-0 pb-0 pt-1 px-0 me-sm-6 me-5">
            <li class="breadcrumb-item text-sm"><a class="opacity-5 text-dark" href="javascript:;">Staff</a></li>
            <li class="breadcrumb-item text-sm text-dark active" aria-current="page">Booking</li>
          </ol>
    </nav>


    <div class="container-fluid py-4">
      <div class="row">
        <!-- REPORT AREA --> 
      </div>
      <div class="row mt-4">
        <div class="col-lg-7 mb-lg-0 mb-4">
          <div 
           class="card">
            <div class="card-body p-3  box-buldge-shadow">
              <div class="row">
                <div class="col-lg-6">
                  <div class="d-flex flex-column h-100">
                    <p class="mb-1 pt-2 text-bold">Welcome Staff, <?php echo $_SESSION["Name"]; ?>!</p>
                    <h4 class="font-weight-bolder">Hotel Booking</h4>
                    <br>
                    <p class="mb-5">Designed By <br> Lyzoo Technologies Pvt Ltd</p>
                    <!-- <a class="text-body text-sm font-weight-bold mb-0 icon-move-right mt-auto" href="javascript:;">
                      Read More
                      <i class="fas fa-arrow-right text-sm ms-1" aria-hidden="true"></i>
                    </a> -->
                  </div>
                </div>
                <div class="col-lg-5 ms-auto text-center mt-5 mt-lg-0">
                  <div style="border-top-left-radius: 40%; border-top-right-radius: 37%;border-bottom-left-radius: 37%;  box-shadow: rgba(0, 0, 0, 0.17) 0px -23px 25px 0px inset, rgba(0, 0, 0, 0.15) 0px -36px 30px 0px inset, rgba(0, 0, 0, 0.1) 0px -79px 40px 0px inset, rgba(0, 0, 0, 0.06) 0px 2px 1px, rgba(0, 0, 0, 0.09) 0px 4px 2px, rgba(0, 0, 0, 0.09) 0px 8px 4px, rgba(0, 0, 0, 0.09) 0px 16px 8px, rgba(0, 0, 0, 0.09) 0px 32px 16px;" 
                    class="bg-gradient-warning h-100">
                    <img src="../assets/img/shapes/waves-white.svg" class="position-absolute h-100 w-50 top-0 d-lg-block d-none" alt="waves">
                    <div class="position-relative d-flex align-items-center justify-content-center h-100">
                      <img  class="w-50 position-relative z-index-2" src="../assets/img/LYZOO-3D-LOGO.png" alt="LYZOO LOGO">
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-5 ">
          <div  
            class="card h-100 p-3 ">
            <div class="overflow-hidden position-relative border-radius-lg bg-cover h-100 " style="background-image: url('../assets/img/ivancik.jpg');">
              <span class="mask bg-gradient-dark"></span>
              <div  
                 class="card-body position-relative z-index-1 d-flex flex-column h-100 p-3 box-buldge-shadow">
                <h5 class="text-white font-weight-bolder mb-4 pt-2">Be a Part of <span style="color: #EC5007">Lyzoo Technologies</span> </h5>
                <p class="text-white text-capitalize">We are Revolutionary Digital Marketing Company pushing towards excellence for our customer's business needs.</p>
                <a class="text-white text-sm font-weight-bold mb-0 icon-move-right mt-auto" href="https://lyzoo.co.in/">
                  Read More
                  <i class="fas fa-arrow-right text-sm ms-1" aria-hidden="true"></i>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="row mt-4 box-buldge-shadow">
      <h3 class="text-center mt-4">Room Availability</h3>

      <div id="rooms-container" class="d-flex flex-wrap justify-content-center mt-5">
    <!-- Room boxes will be dynamically added here -->
      </div>
      
        
      <?php
include("footer-section.php");
?>
    </div>
  </main>

</body>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
    // Function to dynamically generate room boxes
    function generateRoomBoxes(rooms) {
        var container = document.getElementById("rooms-container");

        // Clear any existing room boxes
        container.innerHTML = "";

        // Generate room boxes dynamically based on room data
        rooms.forEach(function (room) {
            var roomBox = document.createElement("div");
            roomBox.className = `room-box ${room.status.toLowerCase() === "booked" ? "booked" : "available"}`;

            roomBox.innerHTML = `
            <h4 class="text-dark mt-3 mb-3 text-bolder">${room.room_no}</h4>
            
            <a href="inventory-list.php"><p><span class="btn btn-sm badge rounded-pill bg-dark ml-5 mr-5">${room.ac_nonac}</span></p></a>
            <p><em>${room.room_type}</em></p>
            <p><strong>${room.status}</strong></p>
            `;

            container.appendChild(roomBox);
        });
    }

    // Function to fetch room data from the server
    function fetchRoomData() {
        $.ajax({
            url: '../admin/fetch-rooms.php',
            type: 'GET',
            dataType: 'json',
            success: function(data) {
                generateRoomBoxes(data);
            },
            error: function() {
                console.error('Error fetching room data');
            }
        });
    }

    // Call the function to fetch room data and generate room boxes on page load
    fetchRoomData();
</script>

</html>