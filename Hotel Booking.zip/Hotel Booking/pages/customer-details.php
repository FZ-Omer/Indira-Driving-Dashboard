<?php
extract($_POST);
include("../connect.php");

$name = $_POST['name'];
$checkin_date = $_POST['checkin_date'];
$checkout_date = $_POST['checkout_date'];
$phone = $_POST['phone'];
$room_no = $_POST['room_no'];



// Check if the room is already booked
$sql = "SELECT `status` FROM `room` WHERE `room_no`='$room_no'";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $status = $row['status'];

    if ($status === 'Booked') {
        // Display error message if the room is already booked
        $error = 'Room has booked already. Please Check In another room!';
        header("Location: customer-list.php?error=" . urlencode($error));
    } else {
        // Update the room status to 'Booked'
        $sql = "UPDATE `room` SET `status`='Booked' WHERE `room_no`='$room_no'";
        $updateResult = $conn->query($sql);

        if(isset($_POST['save']))
    
{ 
        $query="INSERT INTO booking(name, checkin_date, checkout_date, phone, room_no )
         VALUES ('$name', '$checkin_date', '$checkout_date', '$phone', '$room_no')";
        $sql=mysqli_query($conn,$query)or die("Could Not Perform the Query");
        /* If Success */
        $error = 'Booking Details Added Successfully!';
        header("Location: customer-list.php?error=" . urlencode($error));
       
    }
    else 
    {
		echo '<div class="alert alert-primary alert-dismissible" role="alert">
        Error ! Try Again !
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>';
	}

    }
} else {
    // Room not found
    $error = 'The room does not exist.!';
    header("Location: customer-list.php?error=" . urlencode($error));
}

?>