

<?php 

include("../connect.php");

$sql = "SELECT * FROM room";

$result = $conn->query($sql);

?>

<!-- Header TAG -->
<?php
include("header-section.php");
?>

<main class="main-content position-relative max-height-vh-100 h-100 mt-1 border-radius-lg ">
    <!-- Navbar -->
    <nav class="navbar navbar-main navbar-expand-lg px-0 mx-4 shadow-none border-radius-xl" id="navbarBlur" navbar-scroll="true">

          <ol class="breadcrumb bg-transparent mb-0 pb-0 pt-1 px-0 me-sm-6 me-5">
            <li class="breadcrumb-item text-sm"><a class="opacity-5 text-dark" href="javascript:;">Staff</a></li>
            <li class="breadcrumb-item text-sm text-dark active" aria-current="page">Rooms</li>
          </ol>
          
        </nav> 
          <!-- Content wrapper -->
      <div class="content-wrapper">
        <div class="container-xxl flex-grow-1 container-p-y">
        <?php
                   if(isset($_GET['error'])) {
                    $error = $_GET['error'];
                    echo '<div class="alert alert-success alert-dismissible" role="alert">
                    ' . $error . '
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                      </div>'; 
                     }
                ?>
              <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">REPORT /</span> Rooms List</h4>
              <!-- Hided Because Staff should not have access to add new rooms -->
              <!-- <a href="inventory-add.php"><button class="btn btn-success">Add Rooms</button></a> -->
              <div class="table-responsive">
                <table id="example" class="table table-striped table-bordered">
                  <thead>
                    <tr>
                      <th>Room No</th>
                      <th>Room Type</th>
                      <th>Ac / Non AC</th>
                      <th>Meal</th>
                      <th>Bed Capacity</th>
                      <th>Rent</th>
                      <th>Status</th>
                      <th>Action</th>
                      
                      
                    </tr>
                  </thead>
                  <tbody>
                  <?php

if ($result->num_rows > 0) {

    while ($row = $result->fetch_assoc()) {

?>

        <tr>

        <td><?php echo $row['room_no']; ?></td>

        <td><?php echo $row['room_type']; ?></td>

        <td><?php echo $row['ac_nonac']; ?></td>

        <td><?php echo $row['meal']; ?></td>

        <td><?php echo $row['bed_capacity']; ?></td>

        <td><?php echo $row['rent']; ?></td>

        <td><?php echo $row['status']; ?></td>

        <td><a class="btn btn-info" href="inventory-edit.php?id=<?php echo $row['id']; ?>">Edit</a></td>

        </tr>                       

<?php       }

}

?>
                  </tbody>
                </table>
              </div>
         </div>
        </div>
            <!-- Content -->

<!-- ---------------------------SCRIPTS--------------------- -->

    <!-- Footer TAG -->
    <?php
include("footer-section.php");
?>
<!-- DATATABLE FUNCTION -->
<script>
  $(document).ready(function() {
  $('#example').DataTable({
    paging: true,      // enable pagination
    searching: true,   // enable search bar
    // additional options go here
  });
});
</script>



  </body>
</html>