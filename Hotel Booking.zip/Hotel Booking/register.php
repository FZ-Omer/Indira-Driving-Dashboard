<?php
extract($_POST);
include("connect.php");

$name = $_POST['name'];
$email = $_POST['email'];
$password = $_POST['password'];
$phone = $_POST['phone'];

$sql=mysqli_query($conn,"SELECT * FROM register where Email='$email'");
if(mysqli_num_rows($sql)>0)
{
    echo "Email Id Already Exists"; 
	exit;
}
elseif(isset($_POST['signup']))
    
{ 
        $query="INSERT INTO register(name, email, password, phone ) VALUES ('$name', '$email', 'md5($password)', '$phone')";
        $sql=mysqli_query($conn,$query)or die("Could Not Perform the Query");
        echo('Successfully Registered');
        header("Location: index.php"); 
       
    }
    else 
    {
		echo "Error.Please try again";
	}


?>