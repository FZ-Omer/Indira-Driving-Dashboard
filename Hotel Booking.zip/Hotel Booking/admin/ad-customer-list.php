<?php

include("../connect.php");

$sql = "SELECT * FROM booking ORDER BY id DESC";

$result = $conn->query($sql);

// Get the current date
$currentDate = date('Y-m-d');

?>

<!-- Header TAG -->
<?php
include("admin-header.php");
?>

<main class="main-content position-relative max-height-vh-100 h-100 mt-1 border-radius-lg">
    <!-- Navbar -->
    <nav class="navbar navbar-main navbar-expand-lg px-0 mx-4 shadow-none border-radius-xl" id="navbarBlur" navbar-scroll="true">

          <ol class="breadcrumb bg-transparent mb-0 pb-0 pt-1 px-0 me-sm-6 me-5">
            <li class="breadcrumb-item text-sm"><a class="opacity-5 text-dark" href="javascript:;">Admin</a></li>
            <li class="breadcrumb-item text-sm text-dark active" aria-current="page">Booking</li>
          </ol>

    </nav>

    <!-- Content wrapper -->
    <div class="content-wrapper">

        <?php
        if(isset($_GET['error'])) {
            $error = $_GET['error'];
            echo '<div class="alert alert-primary alert-dismissible" role="alert">
                    ' . $error . '
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                  </div>';
        }
        ?>
        
        <div class="container-xxl flex-grow-1 container-p-y">
            <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Booking /</span> Booking Details</h4>
            <a href="ad-customer-add.php"><button class="btn btn-success">New Booking</button></a> <br>
            <a href="?filter=today"><button class="btn btn-primary">Today's Checkout</button></a>
            <a href="ad-customer-list.php"><button class="btn btn-secondary">RESET</button></a>  <!-- Added button for Today's Checkout -->
            <div class="table-responsive">
                <table id="example" class="table table-striped table-bordered">
                    <thead>
                    <tr>
                        <th>Check In Date</th>
                        <th>Check Out Date</th>
                        <th>Room No</th>
                        <th>Full Name</th>
                        <th>Phone Number</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            // Check if the check-out date is the current date
                            if (isset($_GET['filter']) && $_GET['filter'] == 'today' && $row['checkout_date'] == $currentDate) {
                                ?>
                                <tr>
                                    <td><?php echo $row['checkin_date']; ?></td>
                                    <td><?php echo $row['checkout_date']; ?></td>
                                    <td><?php echo $row['room_no']; ?></td>
                                    <td><?php echo $row['name']; ?></td>
                                    <td><?php echo $row['phone']; ?></td>
                                    <td><a class="btn btn-info" href="ad-customer-edit.php?id=<?php echo $row['id']; ?>">Edit</a></td>
                                </tr>
                                <?php
                            } elseif (!isset($_GET['filter'])) { // Display all records if the filter is not set
                                ?>
                                <tr>
                                    <td><?php echo $row['checkin_date']; ?></td>
                                    <td><?php echo $row['checkout_date']; ?></td>
                                    <td><?php echo $row['room_no']; ?></td>
                                    <td><?php echo $row['name']; ?></td>
                                    <td><?php echo $row['phone']; ?></td>
                                    <td><a class="btn btn-info" href="ad-customer-edit.php?id=<?php echo $row['id']; ?>">Edit</a>&nbsp; <a class="btn btn-danger" href="ad-customer-delete.php?id=<?php echo $row['id']; ?>" onclick="confirmDelete(event)">Delete</a></td>
                                </tr>
                                <?php
                            }
                        }
                    }
                    ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
<!-- ---------------------------SCRIPTS--------------------- -->

    <!-- Footer TAG -->
    <?php
    include("../pages/footer-section.php");
    ?>


<script>
function confirmDelete(event) {
  event.preventDefault(); // Prevent the default behavior of the anchor element

  Swal.fire({
    title: 'Are you sure?',
    text: "You won't be able to revert the Booking Data!",
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#17c1e8',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Yes, delete it!'
  }).then((result) => {
    if (result.isConfirmed) {
      window.location.href = event.target.href; // Proceed with the deletion by redirecting to ad-customer-delete.php
    }
  });
}
</script>
<!-- DATATABLE FUNCTION -->
<script>
    $(document).ready(function() {
        $('#example').DataTable({
            paging: false,      // enable pagination
            searching: true,   // enable search bar
            // additional options go here
        });
    });
</script>

</body>
</html>
