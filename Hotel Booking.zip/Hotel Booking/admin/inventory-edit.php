<?php 

include("../connect.php");

    if (isset($_POST['update_room'])) {
      $id = $_POST['id']; 
      $room_no = $_POST['room_no'];
      $room_type = $_POST['room_type'];
      $ac_nonac = $_POST['ac_nonac'];
      $meal = $_POST['meal'];
      $bed_capacity = $_POST['bed_capacity'];
      $rent = $_POST['rent'];
      $status = $_POST['status'];

       
    $sql = "UPDATE `room` SET `room_no`='$room_no', `room_type`='$room_type',`ac_nonac`='$ac_nonac', `meal`='$meal',  `bed_capacity`='$bed_capacity',  `rent`='$rent',  `status`='$status' WHERE `id`='$id'";
    $result = $conn->query($sql);

        if ($result == TRUE) {

          $error = 'Your Room Details Updated Successfully!';
          header("Location: inventory-list.php?error=" . urlencode($error));
          exit;

        }else{

            echo "Error:" . $sql . "<br>" . mysqli_error($conn);

        }

    } 

    

    if (isset($_GET['id'])) {
    
        $id = $_GET['id']; 
    
        $sql = "SELECT * FROM `room` WHERE `id`='$id'";
    
        $result = $conn->query($sql); 
    
        if ($result->num_rows > 0) {        
    
            while ($row = $result->fetch_assoc()) {
    
              $id = $row['id'];
              $room_no = $row['room_no'];
              $room_type = $row['room_type'];
              $ac_nonac = $row['ac_nonac'];
              $meal = $row['meal'];
              $bed_capacity = $row['bed_capacity'];
              $rent = $row['rent'];
              $status = $row['status'];
              
           
            } 
    
          }
        }

    ?>

<!-- Header TAG -->
<?php
include("admin-header.php");
?>
<main class="main-content position-relative max-height-vh-100 h-100 mt-1 border-radius-lg ">
    <!-- Navbar -->
    <nav class="navbar navbar-main navbar-expand-lg px-0 mx-4 shadow-none border-radius-xl" id="navbarBlur" navbar-scroll="true">

          <ol class="breadcrumb bg-transparent mb-0 pb-0 pt-1 px-0 me-sm-6 me-5">
            <li class="breadcrumb-item text-sm"><a class="opacity-5 text-dark" href="javascript:;">Pages</a></li>
            <li class="breadcrumb-item text-sm text-dark active" aria-current="page">Rooms</li>
          </ol>
          
        </nav> 
          <!-- Content wrapper -->
          <div class="content-wrapper">
            <!-- Content -->

            <div class="container-xxl flex-grow-1 container-p-y">
            
              <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Rooms /</span> Update Rooms</h4>
              
              <div class="col-md-6">
                <div class="card mb-4">
                  <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Update Your Room Details </h5>
                    
                  </div>
                  <div class="card-body">
                    <form action="" method="post">
                    <div class="mb-3">
                        <label class="form-label" for="basic-icon-default-fullname">Room No</label>
                        <div class="input-group input-group-merge">
                          <span id="basic-icon-default-fullname2" class="input-group-text"
                            ><i class="fas fa-tag"></i
                          ></span>
                          <input 
                            value="<?php echo $id ?>"
                            name="id"
                            type="hidden"
                            class="form-control"
                            id="basic-icon-default-fullname"
                            placeholder="Example: 101"
                            aria-label="Example: 101"
                            aria-describedby="basic-icon-default-fullname2"
                          />
                          <input
                            value="<?php echo $room_no ?>"
                            name="room_no"
                            type="text"
                            class="form-control"
                            id="basic-icon-default-fullname"
                            placeholder="Example: 101"
                            aria-label="Example: 101"
                            aria-describedby="basic-icon-default-fullname2"
                          />
                        </div>
                      </div>
                      
                      <div class="mb-3">
                        <label class="form-label" for="basic-icon-default-phone">Room Type</label>
                        <div class="input-group input-group-merge">
                          <span id="basic-icon-default-cart" class="input-group-text"
                            >
                            <i class="fas fa-user"></i></span>
                          <input
                            value="<?php echo $room_type ?>"
                            name="room_type"
                            type="text"
                            id="basic-icon-default-phone"
                            class="form-control phone-mask"
                            placeholder="Example: Suite"
                            aria-label="Suite"
                            aria-describedby="basic-icon-default-cart"
                          />
                        </div>
                      </div>
                      <div class="mb-3">
                        <label class="form-label" for="basic-icon-default-phone">AC / Non-AC</label>
                        <div class="input-group input-group-merge">
                          <span id="basic-icon-default-cart" class="input-group-text"
                            ><i class="fas fa-fan"></i
                          ></span>
                          <input
                            value="<?php echo $ac_nonac ?>"
                            name="ac_nonac"
                            type="text"
                            id="basic-icon-default-phone"
                            class="form-control phone-mask"
                            placeholder="Example: None or AC"
                            aria-label="AC"
                            aria-describedby="basic-icon-default-cart"
                          />
                        </div>
                      </div>
                      <div class="mb-3">
                        <label class="form-label" for="basic-icon-default-phone">Meal</label>
                        <div class="input-group input-group-merge">
                          <span id="basic-icon-default-cart" class="input-group-text"
                            ><i class="fas fa-shopping-cart"></i
                          ></span>
                          <input
                            value="<?php echo $meal ?>"
                            name="meal"
                            type="text"
                            id="basic-icon-default-phone"
                            class="form-control phone-mask"
                            placeholder="Example: Breakfast"
                            aria-label="Breakfast"
                            aria-describedby="basic-icon-default-cart"
                          />
                        </div>
                      </div>
                      <div class="mb-3">
                        <label class="form-label" for="basic-icon-default-phone">Bed Capacity</label>
                        <div class="input-group input-group-merge">
                          <span id="basic-icon-default-cart" class="input-group-text"
                            ><i class="fas fa-bed"></i
                          ></span>
                          <input
                            value="<?php echo $bed_capacity ?>"
                            name="bed_capacity"
                            type="text"
                            id="basic-icon-default-phone"
                            class="form-control phone-mask"
                            placeholder="Example: 2"
                            aria-label="Bed Capacity"
                            aria-describedby="basic-icon-default-cart"
                          />
                        </div>
                      </div>
                      <div class="mb-3">
                        <label class="form-label" for="basic-icon-default-phone">Rent</label>
                        <div class="input-group input-group-merge">
                          <span id="basic-icon-default-cart" class="input-group-text"
                            ><i class="fas fa-coins"></i
                          ></span>
                          <input
                            value="<?php echo $rent ?>"
                            name="rent"
                            type="text"
                            id="basic-icon-default-phone"
                            class="form-control phone-mask"
                            placeholder="Example: 5000"
                            aria-label="Rent"
                            aria-describedby="basic-icon-default-cart"
                          />
                        </div>
                      </div>
                      <div class="mb-3">
                        <label class="form-label" for="basic-icon-default-phone">Status</label>
                        <div class="input-group input-group-merge">
                          <span id="basic-icon-default-cart" class="input-group-text"
                            ><i class="fas fa-laptop"></i
                          ></span>
                          <input
                            value="<?php echo $status ?>"
                            name="status"
                            type="text"
                            id="basic-icon-default-phone"
                            class="form-control phone-mask"
                            placeholder="Example: Booked"
                            aria-label="Room Status"
                            aria-describedby="basic-icon-default-cart"
                          />
                        </div>
                      </div>
                      
                      <button name="update_room" type="submit" class="btn btn-primary">Save Details</button>
                    </form>
                   
                    <a href="inventory-list.php"><button  type="submit" class="btn btn-secondary">Cancel</button></a>
                  </div>
                </div>
              </div>
            </div>
            <!-- / Content -->

            <?php
include("../pages/footer-section.php");
?>
  </body>
</html>