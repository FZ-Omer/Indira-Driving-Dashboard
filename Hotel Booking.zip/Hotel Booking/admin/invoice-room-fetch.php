<?php
// room-details-fetch.php
include("../connect.php");
// Retrieve the room number from the query parameter
$roomNo = $_GET['room_no'];

// Perform a query to retrieve the room details based on the room number
$query = "SELECT * FROM room WHERE room_no = '$roomNo'";
$result = $conn->query($query);

if ($result->num_rows > 0) {
  $roomDetails = $result->fetch_assoc();

  // Return the room details as a JSON response
  header('Content-Type: application/json');
  echo json_encode($roomDetails);
}
?>
