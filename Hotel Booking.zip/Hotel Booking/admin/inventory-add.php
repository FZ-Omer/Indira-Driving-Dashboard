<!-- Header TAG -->
<?php
include("admin-header.php");
?>

<main class="main-content position-relative max-height-vh-100 h-100 mt-1 border-radius-lg ">
    <!-- Navbar -->
    <nav class="navbar navbar-main navbar-expand-lg px-0 mx-4 shadow-none border-radius-xl" id="navbarBlur" navbar-scroll="true">

          <ol class="breadcrumb bg-transparent mb-0 pb-0 pt-1 px-0 me-sm-6 me-5">
            <li class="breadcrumb-item text-sm"><a class="opacity-5 text-dark" href="javascript:;">Pages</a></li>
            <li class="breadcrumb-item text-sm text-dark active" aria-current="page">Add Rooms</li>
          </ol>
          
        </nav>  
    <div class="container-fluid py-1 px-3">
      


            <div class="container-xxl flex-grow-1 container-p-y">
              <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Products /</span> Add Rooms</h4>
              
              <div class="col-md-6">
                <div class="card mb-4">
                  <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Sale Product Details Only</h5>
                    
                  </div>
                  <div class="card-body">
                    <form action="inventory-post.php" method="post">
                      <div class="mb-3">
                        <label class="form-label" for="basic-icon-default-fullname">Room No</label>
                        <div class="input-group input-group-merge">
                          <span id="basic-icon-default-fullname2" class="input-group-text"
                            ><i class="fas fa-tag"></i
                          ></span>
                          <input
                            name="room_no"
                            type="text"
                            class="form-control"
                            id="basic-icon-default-fullname"
                            placeholder="Example: 101"
                            aria-label="Example: 101"
                            aria-describedby="basic-icon-default-fullname2"
                          />
                        </div>
                      </div>
                      
                      <div class="mb-3">
                        <label class="form-label" for="basic-icon-default-phone">Room Type</label>
                        <div class="input-group input-group-merge">
                          <span id="basic-icon-default-cart" class="input-group-text"
                            >
                            <i class="fas fa-user"></i></span>
                          <input
                            name="room_type"
                            type="text"
                            id="basic-icon-default-phone"
                            class="form-control phone-mask"
                            placeholder="Example: Suite"
                            aria-label="Suite"
                            aria-describedby="basic-icon-default-cart"
                          />
                        </div>
                      </div>
                      <div class="mb-3">
                        <label class="form-label" for="basic-icon-default-phone">AC / Non-AC</label>
                        <div class="input-group input-group-merge">
                          <span id="basic-icon-default-cart" class="input-group-text"
                            ><i class="fas fa-fan"></i
                          ></span>
                          <input
                            name="ac_nonac"
                            type="text"
                            id="basic-icon-default-phone"
                            class="form-control phone-mask"
                            placeholder="Example: None or AC"
                            aria-label="AC"
                            aria-describedby="basic-icon-default-cart"
                          />
                        </div>
                      </div>
                      <div class="mb-3">
                        <label class="form-label" for="basic-icon-default-phone">Meal</label>
                        <div class="input-group input-group-merge">
                          <span id="basic-icon-default-cart" class="input-group-text"
                            ><i class="fas fa-shopping-cart"></i
                          ></span>
                          <input
                            name="meal"
                            type="text"
                            id="basic-icon-default-phone"
                            class="form-control phone-mask"
                            placeholder="Example: Breakfast"
                            aria-label="Breakfast"
                            aria-describedby="basic-icon-default-cart"
                          />
                        </div>
                      </div>
                      <div class="mb-3">
                        <label class="form-label" for="basic-icon-default-phone">Bed Capacity</label>
                        <div class="input-group input-group-merge">
                          <span id="basic-icon-default-cart" class="input-group-text"
                            ><i class="fas fa-bed"></i
                          ></span>
                          <input
                            name="bed_capacity"
                            type="text"
                            id="basic-icon-default-phone"
                            class="form-control phone-mask"
                            placeholder="Example: 2"
                            aria-label="Bed Capacity"
                            aria-describedby="basic-icon-default-cart"
                          />
                        </div>
                      </div>
                      <div class="mb-3">
                        <label class="form-label" for="basic-icon-default-phone">Rent</label>
                        <div class="input-group input-group-merge">
                          <span id="basic-icon-default-cart" class="input-group-text"
                            ><i class="fas fa-coins"></i
                          ></span>
                          <input
                            name="rent"
                            type="text"
                            id="basic-icon-default-phone"
                            class="form-control phone-mask"
                            placeholder="Example: 5000"
                            aria-label="Rent"
                            aria-describedby="basic-icon-default-cart"
                          />
                        </div>
                      </div>
                      <div class="mb-3">
                        <label class="form-label" for="basic-icon-default-phone">Status</label>
                        <div class="input-group input-group-merge">
                          <span id="basic-icon-default-cart" class="input-group-text"
                            ><i class="fas fa-laptop"></i
                          ></span>
                          <input
                            name="status"
                            type="text"
                            id="basic-icon-default-phone"
                            class="form-control phone-mask"
                            placeholder="Example: Booked"
                            aria-label="Room Status"
                            aria-describedby="basic-icon-default-cart"
                          />
                        </div>
                      </div>
                      
                      <button name="save_product" type="submit" class="btn btn-primary">Save Details</button>
                    </form>
                    
                    <a href="inventory-list.php"><button  type="submit" class="btn btn-secondary">Cancel</button></a>
                  </div>
            
            </div>
            <!-- / Content -->


<?php
include("../pages/footer-section.php");
?>