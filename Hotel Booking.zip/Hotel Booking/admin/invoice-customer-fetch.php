<?php
// invoice-customer-fetch.php
include("../connect.php");
// Retrieve the room number from the query parameter
$roomNo = $_GET['room_no'];

// Perform a query to retrieve the customer details based on the room number
$query = "SELECT * FROM booking WHERE room_no = '$roomNo' AND checkout_date = CURDATE()";
$result = $conn->query($query);

if ($result->num_rows > 0) {
  $customerDetails = $result->fetch_assoc();



  // Return the customer details as a JSON response
  header('Content-Type: application/json');
  echo json_encode($customerDetails);
}
?>
