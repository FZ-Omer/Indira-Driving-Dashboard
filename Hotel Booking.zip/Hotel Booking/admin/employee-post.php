<?php
extract($_POST);
include("../connect.php");

$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$password = $_POST['password'];

$sql=mysqli_query($conn,"SELECT * FROM employees where Email='$email'");
if(mysqli_num_rows($sql)>0)
{
    echo '<div class="alert alert-primary alert-dismissible" role="alert">
    This Email Already Exists! Try Again With Different Email!
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  </div>'; 
	exit;
}
elseif(isset($_POST['save']))
    
{ 
        $query="INSERT INTO employees(name, email, phone, password ) VALUES ('$name', '$email', '$phone', '$password')";
        $sql=mysqli_query($conn,$query)or die("Could Not Perform the Query");
        /* If Success */
        header("Location: employees-list.php"); 
       
    }
    else 
    {
		echo '<div class="alert alert-primary alert-dismissible" role="alert">
        Error ! Try Again !
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>';
	}


?>