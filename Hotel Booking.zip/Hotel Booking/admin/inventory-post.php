<?php
extract($_POST);
include("../connect.php");

$room_no = $_POST['room_no'];
$room_type = $_POST['room_type'];
$ac_nonac = $_POST['ac_nonac'];
$meal = $_POST['meal'];
$bed_capacity = $_POST['bed_capacity'];
$rent = $_POST['rent'];
$status = $_POST['status'];


$sql=mysqli_query($conn,"SELECT * FROM room where room_no = '$room_no' ");
if(mysqli_num_rows($sql)>0)
{
    echo '<div class="alert alert-primary alert-dismissible" role="alert">
    This Product Already Exists! Try Again With Different Product!
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  </div>'; 
	exit;
}
if(isset($_POST['save_product']))
    
{ 
        $query="INSERT INTO room(room_no, room_type, ac_nonac, meal, bed_capacity, rent, status )
         VALUES ('$room_no', '$room_type','$ac_nonac', '$meal', '$bed_capacity', '$rent', '$status' )";
        $sql=mysqli_query($conn,$query)or die("Could Not Perform the Query");
        /* If Success */
        $error = 'Room Details Added Successfully!';
        header("Location: inventory-list.php?error=" . urlencode($error));
       
    }
    else 
    {
		echo '<div class="alert alert-primary alert-dismissible" role="alert">
        Error ! Try Again !
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>';
	}


?>