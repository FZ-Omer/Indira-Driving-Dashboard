<?php
include("../connect.php");

if (isset($_POST['save_invoice'])) {
    $room_no = $_POST['room_no'];
    $customer_name = $_POST['customer_name'];
    $customer_phone = $_POST['customer_phone'];
    $room_type = $_POST['room_type'];
    $ac_nonac = $_POST['ac_nonac'];
    $had_meals = $_POST['had_meals'];
    $meals_cost = $_POST['meals_cost'];
    $room_rent = $_POST['room_rent'];
    $checkin_date = $_POST['checkin_date'];
    $checkout_date = $_POST['checkout_date'];
    $invoice_no = $_POST['invoice_no'];
    $employee_name = $_POST['employee_name'];
    $extra_bed = $_POST['extra_bed'];
    $sub_total = $_POST['sub_total'];
    $gst_value = $_POST['gst_value'];
    $grand_total = $_POST['grand_total'];

        

        // Update remaining stock in product_sale table
        $query = "UPDATE `room` SET `status`='Open' WHERE `room_no`='$room_no';";
        $result = $conn->query($query);
        if (!$result) {
            echo "Error updating remaining stock: " . $conn->mysqli_error($conn);
            exit;
        }

        // Insert values into invoice table
        $query = "INSERT INTO invoice (room_no, customer_name, invoice_no, employee_name, customer_phone, room_type, ac_nonac, had_meals, meals_cost, room_rent, checkin_date, checkout_date, extra_bed, sub_total, gst_value, grand_total)
          VALUES ('$room_no', '$customer_name', '$invoice_no', '$employee_name', '$customer_phone', '$room_type', '$ac_nonac', '$had_meals', '$meals_cost', '$room_rent', '$checkin_date', '$checkout_date', '$extra_bed', '$sub_total', '$gst_value', '$grand_total')";

        $result = $conn->query($query);

    }
    
    if ($result) {
        $error = 'Your Invoice Report Uploaded Successfully! Print Your Invoice Here';
        header("Location: invoice-report.php?error=" . urlencode($error));
        exit;
    } else {
        echo "Error inserting values into invoice table: " . $conn->mysqli_error($conn);
        exit;
    }

?>
