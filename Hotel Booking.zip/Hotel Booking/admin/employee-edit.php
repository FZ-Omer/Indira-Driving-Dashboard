<?php 

include("../connect.php");

    if (isset($_POST['update_employees'])) {
      $id = $_POST['id']; 
      $name = $_POST['name'];
      $email = $_POST['email'];
      $phone = $_POST['phone'];
      $password = $_POST['password'];

       
    $sql = "UPDATE `employees` SET `name`='$name', `email`='$email', `phone`='$phone', `password`='$password'  WHERE `id`='$id'";
    $result = $conn->query($sql);

        if ($result == TRUE) {

          $error = 'Your Employee Details Updated Successfully!';
          header("Location: employees-list.php?error=" . urlencode($error));
          exit;

        }else{

            echo "Error:" . $sql . "<br>" . $conn->mysqli_error($conn);

        }

    } 

    

    if (isset($_GET['id'])) {
    
        $id = $_GET['id']; 
    
        $sql = "SELECT * FROM `employees` WHERE `id`='$id'";
    
        $result = $conn->query($sql); 
    
        if ($result->num_rows > 0) {        
    
            while ($row = $result->fetch_assoc()) {
    
            $id = $row['id'];
            $name = $row['name'];
            $email = $row['email'];
            $phone = $row['phone'];
            $password = $row['password'];
           
            } 
    
          }
        }

    ?>

<!-- Header TAG -->
<?php
include("admin-header.php");
?>
<main class="main-content position-relative max-height-vh-100 h-100 mt-1 border-radius-lg ">
    <!-- Navbar -->
    <nav class="navbar navbar-main navbar-expand-lg px-0 mx-4 shadow-none border-radius-xl" id="navbarBlur" navbar-scroll="true">

          <ol class="breadcrumb bg-transparent mb-0 pb-0 pt-1 px-0 me-sm-6 me-5">
            <li class="breadcrumb-item text-sm"><a class="opacity-5 text-dark" href="javascript:;">Pages</a></li>
            <li class="breadcrumb-item text-sm text-dark active" aria-current="page">Add Inventory</li>
          </ol>
          
        </nav> 
                 <!-- Content wrapper -->
                 <div class="content-wrapper">
            <!-- Content -->

            <div class="container-xxl flex-grow-1 container-p-y">
              <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Pages /</span> Add Employees</h4>
              
              <div class="col-md-6">
                <div class="card mb-4">
                  <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Employees details</h5>
                    
                  </div>
                  <div class="card-body">
                    <form action="" method="post">
                        <div class="mb-3">
                            <label class="form-label" for="basic-icon-default-fullname">Full Name</label>
                            <div class="input-group input-group-merge">
                              <span id="basic-icon-default-fullname2" class="input-group-text"
                                ><i class="bx bx-user"></i
                              ></span>
                              <input
                            name="id"
                            type="hidden"
                            value="<?php echo $id ?>"
                            class="form-control"
                            id="basic-icon-default-fullname"
                            placeholder="John Doe"
                            aria-label="John Doe"
                            aria-describedby="basic-icon-default-fullname2"
                          />
                              <input required
                                type="text"
                                name="name"
                                value="<?php echo $name ?>"
                                class="form-control"
                                id="basic-icon-default-fullname"
                                placeholder="John Doe"
                                aria-label="John Doe"
                                aria-describedby="basic-icon-default-fullname2"
                              />
                            </div>
                          </div>
                          
                          <div class="mb-3">
                            <label class="form-label" for="basic-icon-default-email">Email</label>
                            <div class="input-group input-group-merge">
                              <span class="input-group-text"><i class="bx bx-envelope"></i></span>
                              <input required
                                type="text"
                                name="email"
                                value="<?php echo $email ?>"
                                id="basic-icon-default-email"
                                class="form-control"
                                placeholder="john.doe"
                                aria-label="john.doe"
                                aria-describedby="basic-icon-default-email2"
                              />
                              <span id="basic-icon-default-email2" class="input-group-text">@example.com</span>
                            </div>
                            <div class="form-text">You can use letters, numbers & periods</div>
                          </div>
                          <div class="mb-3">
                            <label class="form-label" for="basic-icon-default-phone">Phone No</label>
                            <div class="input-group input-group-merge">
                              <span id="basic-icon-default-phone2" class="input-group-text"
                                ><i class="bx bx-phone"></i
                              ></span>
                              <input required
                                type="text"
                                name="phone"
                                value="<?php echo $phone ?>"
                                id="basic-icon-default-phone"
                                class="form-control phone-mask"
                                placeholder="658 799 8941"
                                aria-label="658 799 8941"
                                aria-describedby="basic-icon-default-phone2"
                              />
                            </div>
                          </div>
                          <div class="mb-3">
                            <label class="form-label" for="basic-icon-default-phone">Password</label>
                            <div class="input-group input-group-merge">
                              <span id="basic-icon-default-phone2" class="input-group-text"
                                ><i class="bx bx-phone"></i
                              ></span>
                              <input required
                                type="text"
                                name="password"
                                value="<?php echo $password ?>"
                                id="basic-icon-default-phone"
                                class="form-control phone-mask"
                                placeholder="Employee Password"
                                aria-label="Employee Password"
                                aria-describedby="basic-icon-default-phone2"
                              />
                            </div>
                          </div>
                      <button name="update_employees" type="submit" class="btn btn-primary">Save Details</button>
                     
                    </form>
                   
                    <a href="employees-list.php"><button  type="submit" class="btn btn-secondary">Cancel</button></a>
                  </div>
                </div>
              </div>
            </div>
            <!-- / Content -->

            <?php
include("../pages/footer-section.php");
?>
  </body>
</html>