<?php

include("../connect.php");

if (isset($_GET['id'])) {
    $invoice_no = $_GET['id'];

    $sql = "SELECT *  FROM invoice ";

    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $id = $row['id'];
            $invoice_no = $row['invoice_no'];
            $room_no = $row['room_no'];
            $customer_name = $row['customer_name'];
            $customer_phone = $row['customer_phone'];
            $room_type = $row['room_type'];
            $ac_nonac = $row['ac_nonac'];
            $had_meals = $row['had_meals'];
            $meals_cost = $row['meals_cost'];
            $room_rent = $row['room_rent'];
            $checkin_date = $row['checkin_date'];
            $checkout_date = $row['checkout_date'];
            $invoice_no = $row['invoice_no'];
            $employee_name = $row['employee_name'];
            $extra_bed = $row['extra_bed'];
            $sub_total = $row['sub_total'];
            $gst_value = $row['gst_value'];
            $grand_total = $row['grand_total'];            
            
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice - Page</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css"
        integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
</head>

<body>

    <div style="margin-left: 170px ;margin-right: 50px ;" class="container">
        <div id="ui-view" data-select2-id="ui-view">

            <div>
                <div class="card">
                    <div class="text-center pt-5 card-header">
                        <!-- <img style="width: 300px;height: 80px;" src="../assets/Images/logo-1.png" alt=""> -->
                        <br>
                        <h1>Quick Bill Invoice</h1>
                        <br>
                        <h5>DR. KAMAKSHI MEMORIAL HOSPITAL, <br>
                            287a, 11th Main Rd, Ram Nagar South Extension, <br>
                            Ram Nagar South, backside, <br>
                            Chennai, Tamil Nadu 600100.</h5>
                        <br>
                        <h6>Phone: +91 90433 34314</h6>
                        <br>
                    </div>
                    <div class="card-header">Invoice #
                        <strong><?php echo $invoice_no ?></strong>
                        <a class="btn btn-sm btn-secondary float-right mr-1 d-print-none" href="#"
                            onclick="javascript:window.print();" data-abc="true">
                            <i class="fa fa-print"></i> Print</a>
                        <a class="btn btn-sm btn-info float-right mr-1 d-print-none" href="admin.php"
                            data-abc="true">
                            <i class="fa fa-save"></i> Homepage</a>
                    </div>
                    <div class="card-body">
                        <div class="row mb-4">
                            <div class="col-sm-4">
                                <h6 class="mb-3">To:</h6>
                                <div>
                                    <strong>Customer Name:  <?php echo $customer_name ?></strong>
                                </div>
                                

                                <div><strong>Phone:</strong> <?php echo $customer_phone ?></div>
                            </div>

                            <div class="col-sm-4">
                                <!-- <h6 class="mb-3">To:</h6>
                                <div>
                                    <strong>BBBootstrap.com</strong>
                                </div>
                                <div>42, Awesome Enclave</div>
                                <div>New York City, New york, 10394</div>
                                <div>Email: admin@bbbootstrap.com</div>
                                <div>Phone: +48 123 456 789</div> -->
                            </div>

                            <div class="col-sm-4">
                                <h6 class="mb-3">Details:</h6>
                                <div><strong>Invoice #</strong>
                                    <?php echo $invoice_no ?>
                                </div>
                                <div><strong>Check In Date : </strong><?php echo $checkin_date ?></div>

                                <div><strong>Check Out Date : </strong><?php echo $checkout_date ?></div>
                               
                            </div>

                        </div>

                        <div class="table-responsive-sm">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th class="center">#</th>
                                        <th>Room Type</th>
                                        <th class="center">AC / Non AC</th>
                                        <th class="center">Room Rent</th>
                                        <th class="right">Gst Value%</th>
                                       
                                    </tr>
                                </thead>
                                <tbody>
                        
                                    <tr>
                                        <td class="center"><?php echo  1 ?></td>
                                        <td class="left"><?php echo $room_type ?></td>
                                        <td class="center"><?php echo $ac_nonac ?></td>
                                        <td class="center"><?php echo $room_rent ?></td>
                                        <td class="right gstvalue"><?php echo $gst_value ?></td>
                                        
                                    </tr>
            

                                </tbody>
                            </table>
                        </div>
                        <div class="row">
                            <div class="col-lg-4 col-sm-5">TERMS & CONDITIONS: 
                            </div>
                            <div class="col-lg-4 col-sm-5 ml-auto">
                                <table class="table table-clear">
                                    <tbody>
                                        <tr>
                                            <td class="left">
                                                <strong>Subtotal</strong>
                                            </td>
                                            <td class="right subtotal">₹<?php echo $sub_total ?></td>
                                        </tr>
                                        <tr>
                                            <td class="left">
                                                <strong>CGST</strong>
                                            </td>
                                            <td class="right cgst"></td>
                                        </tr>
                                        <tr>
                                            <td class="left">
                                                <strong>SGST</strong>
                                            </td>
                                            <td class="right sgst"></td>
                                        </tr>
                                        <tr>
                                            <td class="left">
                                                <strong>Total</strong>
                                            </td>
                                            <td class="right">
                                                <strong>₹<?php echo $grand_total ?></strong>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                                <!-- <a class="btn btn-success" href="#" data-abc="true">
                                    <i class="fa fa-usd"></i> Proceed to Payment</a> -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
window.onload = function() {
    var gstValueText = document.querySelector('.gstvalue').innerText;
    var subtotalText = document.querySelector('.subtotal').innerText;
    
    var cgst = 0;
    var sgst = 0;
    
    var gstPercentage = parseFloat(gstValueText);
    var subtotal = parseFloat(subtotalText.replace('₹', '')); // Remove the currency symbol before parsing
    
    if (!isNaN(gstPercentage) && !isNaN(subtotal)) {
        var gstAmount = (subtotal * gstPercentage) / 100;
        cgst = sgst = gstAmount / 2;
    }
    
    document.querySelector('.cgst').textContent = cgst.toFixed(2);
    document.querySelector('.sgst').textContent = sgst.toFixed(2);
};
</script>






</body>



</html>
