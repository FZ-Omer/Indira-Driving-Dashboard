<?php
include("../connect.php");
// Retrieve the selected customer ID from the query string
$customerId = $_GET["id"];

// Perform your database query to retrieve the customer's full name and phone number
// Replace this with your actual database query code
$query = "SELECT name, phone FROM booking WHERE id = $customerId";
$result = $conn->query($query);

if ($result->num_rows > 0) {
  $customerData = $result->fetch_assoc();

  // Encode the customer data as JSON and send it as the response
  echo json_encode($customerData);
} else {
  // No customer data found
  echo json_encode(null);
}
?>