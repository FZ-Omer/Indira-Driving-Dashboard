<?php 

include("../connect.php");

if (isset($_GET['id'])) {

    $id = $_GET['id'];

    $sql = "DELETE FROM `employees` WHERE `id`='$id'";

     $result = $conn->query($sql);

     if ($result == TRUE) {

        // Display a success message using an alert component
        $error = 'Your Employee Details Deleted Successfully!';
          header("Location: employees-list.php?error=" . urlencode($error));
          exit;

    } else {

        // Display an error message using an alert component
        echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">';
        echo 'Error: ' . $sql . '<br>' . $conn->mysqli_error($conn);
        $error = 'Error Something went  wrong!';
          header("Location: employees-list.php?error=" . urlencode($error));
          exit;

    }

} 

?>