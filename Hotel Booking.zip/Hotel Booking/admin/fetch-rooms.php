<?php
// Include the file with database connection details
require_once '../connect.php';

// Perform the database query
$query = "SELECT room_no, room_type, ac_nonac, status FROM room ORDER BY room_no ASC";
$result = $conn->query($query);

// Prepare the room data
$rooms = array();
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $rooms[] = $row;
    }
}

// Close the database connection
$conn->close();

// Return the room data as JSON response
header("Content-Type: application/json");
echo json_encode($rooms);
?>
