<?php
// Retrieve the name parameter from the POST data

include("../connect.php");


$product_name = $_POST['product_name'];

// Build the SQL query to retrieve the phone, GST, and address for the selected name
$query = "SELECT * FROM product_sale WHERE product_name = '$product_name'";

// Execute the query and retrieve the result
$result = mysqli_query($conn, $query);

// Retrieve the row from the result as an associative array
if($result) {
	$user = mysqli_fetch_assoc($result);
	$response = array(
		'user_id' => $user['id'],
		'product_name' => $user['product_name'],
		'product_price' => $user['product_price'],
		'stock' => $user['stock']
		
	);
    echo json_encode($response);
} else {
	echo json_encode(array('error' => 'Database query error.'));
}
?>
