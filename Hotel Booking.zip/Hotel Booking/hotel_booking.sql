-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 16, 2023 at 07:12 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hotel_booking`
--

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `id` int(11) NOT NULL,
  `name` varchar(250) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `room_no` varchar(10) NOT NULL,
  `checkin_date` varchar(50) DEFAULT NULL,
  `checkout_date` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`id`, `name`, `phone`, `room_no`, `checkin_date`, `checkout_date`) VALUES
(3, 'Umar', '9234567890', '101', '2023-06-13', '2023-06-14'),
(5, 'Angel Jansi', '8838162523', '201', '2023-06-13', '2023-06-15'),
(6, 'Sekar', '9812223344', '202', '2023-06-14', '2023-06-15');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `password` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id`, `name`, `email`, `phone`, `password`) VALUES
(1, 'manoj', 'manoj@gmail.com', '9178994704', 'manoj@123456');

-- --------------------------------------------------------

--
-- Table structure for table `invoice`
--

CREATE TABLE `invoice` (
  `id` int(11) NOT NULL,
  `room_no` varchar(10) NOT NULL,
  `customer_name` varchar(250) NOT NULL,
  `invoice_no` varchar(50) NOT NULL,
  `employee_name` varchar(250) NOT NULL,
  `customer_phone` varchar(10) NOT NULL,
  `room_type` varchar(50) NOT NULL,
  `ac_nonac` varchar(10) NOT NULL,
  `had_meals` varchar(250) NOT NULL,
  `meals_cost` varchar(100) NOT NULL,
  `room_rent` varchar(100) NOT NULL,
  `checkin_date` varchar(50) NOT NULL,
  `checkout_date` varchar(50) NOT NULL,
  `extra_bed` varchar(50) NOT NULL,
  `gst_value` varchar(10) NOT NULL,
  `sub_total` varchar(100) NOT NULL,
  `grand_total` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `invoice`
--

INSERT INTO `invoice` (`id`, `room_no`, `customer_name`, `invoice_no`, `employee_name`, `customer_phone`, `room_type`, `ac_nonac`, `had_meals`, `meals_cost`, `room_rent`, `checkin_date`, `checkout_date`, `extra_bed`, `gst_value`, `sub_total`, `grand_total`) VALUES
(2, '101', 'Umar', 'INV0001', 'manoj', '9234567890', 'Deluxe', 'AC', 'None', '500', '3000', '2023-06-13', '2023-06-14', '500', '18', '4000.00', '4720.00'),
(4, '201', 'Angel Jansi', 'INV0002', 'Staff', '8838162523', 'Executive', 'AC', 'Dinner Buffet', '1200', '7000', '2023-06-13', '2023-06-15', '0', '18', '15200.00', '17936.00'),
(5, '202', 'Sekar', 'INV00003', 'Select Employee name', '9812223344', 'Executive', 'AC', 'None', '0', '7000', '2023-06-14', '2023-06-15', '500', '12', '7500.00', '8400.00');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(250) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `password` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `name`, `email`, `phone`, `password`) VALUES
(1, 'Angel Jansi', 'jansijo5756@gmail.com', '9884631330', 'md5(12345)'),
(2, '', '', '', 'md5()'),
(3, 'Angel Jansi', 'angeljansi1430@gmail.com', '7876554323', 'md5(12345)'),
(4, 'umar', 'umar234@gmail.com', '7687656456', 'md5(123456)'),
(5, 'Abirami', 'abirami123@gmail.com', '92738134567', 'md5(123456)'),
(6, 'josh', 'josh123@gmail.com', '917899470420', 'md5(12345)'),
(7, 'demo', 'demo@gmail.com', '9812223344', 'md5(demo123)');

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE `room` (
  `id` int(11) NOT NULL,
  `room_no` varchar(10) NOT NULL,
  `room_type` varchar(200) NOT NULL,
  `ac_nonac` varchar(10) NOT NULL,
  `meal` varchar(50) NOT NULL,
  `bed_capacity` varchar(10) NOT NULL,
  `rent` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`id`, `room_no`, `room_type`, `ac_nonac`, `meal`, `bed_capacity`, `rent`, `status`) VALUES
(1, '101', 'Deluxe', 'AC', 'None', '2', '3000', 'Open'),
(2, '102', 'Suite', 'AC', 'Lunch', '2', '5000', 'Open'),
(3, '103', 'Deluxe', 'AC', 'None', '2', '3000', 'Open'),
(4, '106', 'Suite', 'AC', 'None', '2', '5000', 'Open'),
(5, '104', 'Deluxe', 'Non Ac', 'None', '2', '2000', 'Open'),
(6, '105', 'Deluxe', 'Non Ac', 'None', '2', '2000', 'Open'),
(7, '201', 'Executive', 'AC', 'None', '2', '7000', 'Booked'),
(8, '202', 'Executive', 'AC', 'None', '2', '7000', 'Open');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `invoice`
--
ALTER TABLE `invoice`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `room`
--
ALTER TABLE `room`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `invoice`
--
ALTER TABLE `invoice`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `room`
--
ALTER TABLE `room`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
