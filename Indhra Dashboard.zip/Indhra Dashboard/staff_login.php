<?php
session_start();
if(isset($_POST['login']))
{
    extract($_POST);
    include 'connect.php';

    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql=mysqli_query($conn,"SELECT * FROM staff where username='$username' and password='$password'");
    $row  = mysqli_fetch_array($sql);
    if(is_array($row))
    {
        $_SESSION["user_id"] = $row['id'];
        $_SESSION["Name"]=$row['name'];
        
        if ($row['role'] == 'staff_grade_1') {
            header("Location: template/staff/dashboard.php");
        } elseif ($row['role'] == 'instructor') {
            $_SESSION['role'] = 'instructor';
            header("Location: template/instructor/dashboard.php");
        } else {
            // Handle other roles or error cases here
        }
    }
    else
    {
        $error = 'Your Email or Password is Incorrect! Please Check and Try Again';
        header("Location: index.php?error=" . urlencode($error));
    }
}
?>



<!-- 
session_start();

include("connect.php");
// Handle login form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Query the database for the user
    $query = "SELECT * FROM staff WHERE username = '$username'";
    $result = mysqli_query($conn, $query);
    $user = mysqli_fetch_assoc($result);

    // Verify user exists and password is correct
    if ($user && password_verify($password, $user['password'])) {
        // Set session variables for the logged-in user
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'];

        // Redirect to the appropriate page based on user role
        switch ($user['role']) {
            case 'instructor':
                header('Location: template/instructor/dashboard.php');
                break;
            case 'staff_grade_1':
                header('Location: template/staff/staff_grade_1_dashboard.php');
                break;
            case 'staff_grade_2':
                header('Location: template/staff/staff_grade_1_dashboard.php');
                break;
        }
        exit();
    } else {
        $error = "Invalid username or password.";
    }
}

// Close the database connection
mysqli_close($conn);
?> -->
