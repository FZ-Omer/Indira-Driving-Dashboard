<?php
session_start();

include'connect.php';
// Handle login form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Query the database for the user
    $query = "SELECT * FROM staff WHERE username = '$username'";
    $result = mysqli_query($conn, $query);
    $user = mysqli_fetch_assoc($result);

    // Verify user exists and password is correct
    if ($user && password_verify($password, $user['password'])) {
        // Set session variables for the logged-in user
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'];

        // Redirect to the appropriate page based on user role
        switch ($user['role']) {
            case 'instructor':
                header('Location: ../instructor/dashboard.php');
                break;
            case 'staff_grade_1':
                header('Location: ../staff/staff_grade_1_dashboard.php');
                break;
            case 'staff_grade_2':
                header('Location: ../staff/staff_grade_1_dashboard.php');
                break;
        }
        exit();
    } else {
        $error = "Invalid username or password.";
    }
}

// Close the database connection
mysqli_close($conn);
?>
