<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Indira Driving School | Admin Login</title>
  <!-- base:css -->
  <link rel="stylesheet" href="template/vendors/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="template/vendors/base/vendor.bundle.base.css">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="template/css/style.css">
  <!-- endinject -->
  <link rel="shortcut icon" href="template/images/favicon.png" />

</head>

<body>
  <div class="container-scroller">
    <div class="container-fluid page-body-wrapper full-page-wrapper">
      <div class="main-panel"  style="background-image: url(template/images/auth/bg.jpg);background-size: 86rem;">
        <div class="content-wrapper d-flex align-items-center auth px-0">
          <div class="row w-100 mx-0 justify-content-end">
            <div class="col-lg-4">
              <div class="auth-form-light text-left py-5 px-4 px-sm-5">
                <div class="brand-logo">
                  <img src="template/images/logo.png" alt="logo">
                </div>

                <h4>Hello Admin! Let's Get Started</h4>
                <h6 class="font-weight-light">Sign in to continue.</h6>
                <form class="pt-3" method="post" action="login.php">
                  <div class="form-group">
                    <input name="email" type="email" class="form-control form-control-lg" id="exampleInputEmail1" placeholder="Enter Your Username">
                  </div>
                  <div class="form-group password-wrapper">
                    <span class="password-toggle" onclick="togglePasswordVisibility()">
                      <i id="eyeIcon" class="mdi mdi-eye" aria-hidden="true"></i>
                    </span>
                    <input name="password" type="password" class="form-control form-control-lg" id="password" placeholder="Password">
                  </div>
                  <div class="mt-3">
                    <input name="login" class="btn btn-block btn-primary btn-lg font-weight-medium auth-form-btn btn-rounded" type="submit" value="SIGN IN">

                  </div>
                  
                  <div class="my-2 d-flex justify-content-between align-items-center">
                    <div class="form-check">
                      <label class="form-check-label text-muted">
                        <input type="checkbox" class="form-check-input">
                      Are You Working Staff ? <br>Please Login Here..
                      </label>
                    </div>
                    <a href="staff.php" class="auth-link text-black">Staff Login</a>
                  </div>
            
                </form>

              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- content-wrapper ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->
  <!-- base:js -->
  <script src="template/vendors/base/vendor.bundle.base.js"></script>
  <!-- endinject -->
  <!-- inject:js -->
  <script src="template/js/template.js"></script>
  <!-- endinject -->
  <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
  <script>
    function togglePasswordVisibility() {
      var passwordInput = document.getElementById("password");
      var eyeIcon = document.getElementById("eyeIcon");

      if (passwordInput.type === "password") {
        passwordInput.type = "text";
        eyeIcon.classList.remove("mdi-eye");
        eyeIcon.classList.add("mdi-eye-off");
      } else {
        passwordInput.type = "password";
        eyeIcon.classList.remove("mdi-eye-off");
        eyeIcon.classList.add("mdi-eye");
      }
    }
  </script>
</body>

</html>
