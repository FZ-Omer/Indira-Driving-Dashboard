<?php
session_start();
if(isset($_POST['login']))
{
    extract($_POST);
    include 'connect.php';
    

    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql=mysqli_query($conn,"SELECT * FROM register where email='$email' and password='$password'");
    $row  = mysqli_fetch_array($sql);
    if(is_array($row))
    {
        $_SESSION["ID"] = $row['id'];
        $_SESSION["Email"]=$row['email'];
        $_SESSION["Name"]=$row['name'];
        // $_SESSION['login_success'] = true;
        
        header("Location: template/dashboard.php"); 
       
    }
    else
    {
        $error = 'Your Email or Password is Incorrect! Please Check and Try Again';
        header("Location: index.php?error=" . urlencode($error));
    }
}
?>