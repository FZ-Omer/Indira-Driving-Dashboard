<?php
    session_start();
    unset($_SESSION["user_id"]);
    unset($_SESSION["Name"]);
    header("Location: ../../index.php");
?>