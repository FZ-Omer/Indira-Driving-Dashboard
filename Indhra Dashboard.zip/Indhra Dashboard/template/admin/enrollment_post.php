<?php
extract($_POST);
include("../../connect.php");

$name = $_POST['name'];
$enquiry = $_POST['enquiry'];
$fathername = $_POST['fathername'];
$dob = $_POST['dob'];
$photo = $_FILES['photo'];
$address = $_POST['address'];
$reference = $_POST['reference'];
$mobile = $_POST['mobile'];
$blood = $_POST['blood'];
$point = $_POST['point'];
$enroll14 = $_POST['enroll14 '];
$llrdate = $_POST['llrdate'];
$validity = $_POST['validity'];
$classname = $_POST['classname'];
$nfd = $_POST['nfd'];
$classdetails = $_POST['classdetails'];
$enr_id = $_POST['enr_id'];



if(isset($_POST['staff_details']))
    
{ 
  if (isset($photo) && $photo['error'] === UPLOAD_ERR_OK) {
  // Get the temporary file path
  $tmpFilePath = $photo['tmp_name'];

  // Read the contents of the temporary file
  $photoData = file_get_contents($tmpFilePath);

  // Escape special characters in the photo data
  $escapedPhotoData = mysqli_real_escape_string($conn, $photoData);
        $query = "INSERT INTO enrollment(name, enquiry, fathername, dob, photo, address, reference, mobile, blood, point, enroll14, llrdate, validity, classname, nfd, classdetails, enr_id) 
          VALUES ('$name', '$enquiry', '$fathername', '$dob', '$photo', '$address', '$reference', '$mobile', '$blood', '$point', '$enroll14', '$llrdate', '$validity', '$classname', '$nfd', '$classdetails', '$enr_id')";
        $sql=mysqli_query($conn,$query)or die("Could Not Perform the Query");
        /* If Success */
        header("Location: enrollment_list.php"); 
       
    }
    else 
    {
    echo '<div class="alert alert-primary alert-dismissible" role="alert">
        Error ! Try Again !
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>';
  }


?>