    <?php
    extract($_POST);
    include("../../connect.php");
    $class_name = $_POST['package'];
    $working = $_POST['working'];
    $fees = $_POST['fees'];
    $nfd = $_POST['nfd'];


    if(isset($_POST['save_rc']))
        
    { 
            $query = "INSERT INTO classes_rc (class_name,working, fees, nfd) 
              VALUES ('$class_name,$working', '$fees', '$nfd')";
            $sql=mysqli_query($conn,$query)or die("Could Not Perform the Query");
            /* If Success */
            header("Location: classes_list.php"); 
           
        }
        else 
        {
        echo '<div class="alert alert-primary alert-dismissible" role="alert">
            Error ! Try Again !
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>';
      }


    ?>