<?php
extract($_POST);
include("../../connect.php");

$name = $_POST['name'];
$classes = $_POST['classes'];
$dfa = $_POST['dfa'];
$total_amt = $_POST['total_amt'];
$discount_amt = $_POST['discount_amt'];
$ref_name = $_POST['ref_name'];
$mobile_no = $_POST['mobile_no'];



if(isset($_POST['save_discount']))
    
{ 
        $query = "INSERT INTO discount (name, classes, dfa, total_amt, discount_amt, ref_name, mobile_no) 
          VALUES ('$name', '$classes', '$dfa', '$total_amt', '$discount_amt', '$ref_name', '$mobile_no')";
        $sql=mysqli_query($conn,$query)or die("Could Not Perform the Query");
        /* If Success */
        header("Location: discount_list.php"); 

       
    }
    else 
    {
    echo '<div class="alert alert-primary alert-dismissible" role="alert">
        Error ! Try Again !
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>';
  }


?>
