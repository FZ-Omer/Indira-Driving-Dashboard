
<?php
include("admin-header.php");
?>        
<!-- partial -->
<div class="container-fluid page-body-wrapper">
  <div class="main-panel">
    <div class="content-wrapper">
      <div class="row" >

        <div class="col-8 mt-5 offset-2" style="box-shadow: rgba(0, 0, 0, 0.56) 0px 22px 70px 4px; ">


          <table id="myTable" class="table table-striped table-bordered">
            <a href="enrollment.php"><button class="btn  offset-10 text-white" style="background-color: #9e1017;">+ Add Enrollment</button></a>
            <thead>
              <tr>
                <th>S.No</th>
                <th>Class Name</th>
                <th>No Of Days</th>
                <th>Simmulation</th>
                <th>On Road</th>
                <th>Theory</th>
                <th>Reverse</th>
                <th>Test Round</th>
              </tr>
            </thead>
            <tbody>

              <!-- Add more rows as needed -->
            </tbody>
          </table>

        </div>








        
      </div>
    </div>
    <!-- content-wrapper ends -->
    <!-- partial:../../partials/_footer.html -->

    <!-- partial -->
  </div>
  <!-- main-panel ends -->
</div>
<!-- page-body-wrapper ends -->

<?php
include("admin-footer.php");
?>