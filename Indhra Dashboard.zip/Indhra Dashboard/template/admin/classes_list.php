<?php 
include("../../connect.php");

// Retrieve all classes
$sql = "SELECT * FROM classes_rc";
$result = $conn->query($sql);
?>




<?php
include("admin-header.php");
?>

<div class="container-fluid page-body-wrapper">
  <div class="main-panel">
    <div class="content-wrapper">
      <div class="row">
        <div class="col-md-8 mx-auto mt-5">
          <div class="card shadow-sm">
            <div class="card-header bg-danger text-white">
              <h1 class="mb-0">Rc Classes</h1>
            </div>
            <div class="card-body table-responsive">
              <table id="myTable" class="table table-striped table-bordered">
                <thead>
                  <tr>
                    <th>S.No</th>
                    <th>Class Name</th>
                    <th>Working</th>
                    <th>No Of Days</th>
                    <th>Fees</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                      $class_id = $row['id']; // Get the class ID
                  ?>
                      <tr>
                        <td><?php echo $row['id']; ?></td>
                        <td><?php echo $row['class_name']; ?></td>
                        <td><?php echo $row['working']; ?></td>
                        <td><?php echo $row['nfd']; ?></td>
                        <td><?php echo $row['fees']; ?></td>
                        <td>
                          <a class="btn btn-info" href="#" data-bs-toggle="modal" data-bs-target="#editModal<?php echo $class_id; ?>">Edit</a>&nbsp;
                          <a class="btn btn-danger" href="employee-delete.php?id=<?php echo $row['id']; ?>" onclick="confirmDelete(event)">Delete</a>
                        </td>
                      </tr>

                      <!-- Modal form -->
                      <div class="modal fade" id="editModal<?php echo $class_id; ?>" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                          <div class="modal-content">
                            <div class="modal-header bg-danger text-white">
                              <h5 class="modal-title"  id="editModalLabel">Edit Class Details</h5>
                              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                              <!-- Form fields for editing class data -->
                              <form action="classes-edit.php" method="post">
                                <fieldset>
                                  <legend >Edit Class Details:</legend>
                                  <div class="mb-3">
                                    <label for="class_name" class="form-label">Class Name:</label>
                                    <input type="text" name="class_name" id="class_name" class="form-control" value="<?php echo $row['class_name']; ?>">
                                  </div>
                                  <div class="mb-3">
                                    <label for="working" class="form-label">Working:</label>
                                    <input type="text" name="working" id="working" class="form-control" value="<?php echo $row['working']; ?>">
                                  </div>
                                  <div class="mb-3">
                                    <label for="fees" class="form-label">Fees:</label>
                                    <input type="text" name="fees" id="fees" class="form-control" value="<?php echo $row['fees']; ?>">
                                  </div>
                                  <div class="mb-3">
                                    <label for="nfd" class="form-label">NFD:</label>
                                    <input type="text" name="nfd" id="nfd" class="form-control" value="<?php echo $row['nfd']; ?>">
                                  </div>
                                  <input type="hidden" name="class_id" value="<?php echo $class_id; ?>">
                                  <input type="submit" value="Update" name="update" class="btn btn-primary">
                                </fieldset>
                              </form>

                            </div>
                          </div>
                        </div>
                      </div>
                  <?php
                    }
                  } else {
                    echo "<tr><td colspan='6'>No staff members found</td></tr>";
                  }
                  ?>
                </tbody>

            
              </table>
            </div>






            <div class="card-footer text-center">
              <a href="classes.php"><button class="btn btn-danger">+ Add Classes</button></a>
            </div>
          </div>
        </div>
      </div>
    </div>

        <div class="content-wrapper">
          <?php 
include("../../connect.php");

// Retrieve all classes
$sql = "SELECT * FROM classes_dl";
$result = $conn->query($sql);
?>

      <div class="row">
        <div class="col-md-8 mx-auto mt-5">
          <div class="card shadow-sm">
            <div class="card-header bg-danger text-white">
              <h1 class="mb-0">DL Classes</h1>
            </div>
            <div class="card-body table-responsive">
              <table id="myTable" class="table table-striped table-bordered">
                <thead>
                  <tr>
                    <th>S.No</th>
                    <th>Class Name</th>
                    <th>Fees</th>
                    <th>No Of Days</th>
                    <th>Simulation</th>
                    <th>On Road</th>
                    <th>Theory</th>
                    <th>Reverse</th>
                    <th>Test Round</th>
                  </tr>
                </thead>
              <tbody>
  <?php
  if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
      $class_id = $row['id']; // Get the class ID
      ?>
      <tr>
        <td><?php echo $row['id']; ?></td>
        <td><?php echo $row['package_name']; ?></td>
        <td><?php echo $row['fees']; ?></td>
        <td><?php echo $row['nfd']; ?></td>
        <td><?php echo $row['simulation']; ?></td>
        <td><?php echo $row['onroad']; ?></td>
        <td><?php echo $row['theory']; ?></td>
        <td><?php echo $row['reverse']; ?></td>
        <td><?php echo $row['testround']; ?></td>
        <td>
          <a class="btn btn-info" href="#" data-bs-toggle="modal" data-bs-target="#dlModal<?php echo $class_id; ?>">Edit</a><br><br>
          <a class="btn btn-danger" href="classes-delete.php?id=<?php echo $row['id']; ?>" onclick="confirmDelete(event)">Delete</a>
        </td>
      </tr>

      <!-- Modal form -->
      <div class="modal fade" id="dlModal<?php echo $class_id; ?>" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header bg-danger text-white">
              <h5 class="modal-title" id="editModalLabel">Edit Class Details</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              <!-- Form fields for editing class data -->
              <form action="classes-dl-edit.php" method="post">
                <fieldset>
                  <legend>Edit Class Details:</legend>
                  <div class="mb-3">
                    <label for="class_name" class="form-label">Class Name:</label>
                    <input type="text" name="package_name" id="class_name" class="form-control" value="<?php echo $row['package_name']; ?>">
                  </div>
                  <div class="mb-3">
                    <label for="fees" class="form-label">Fees:</label>
                    <input type="text" name="fees" id="fees" class="form-control" value="<?php echo $row['fees']; ?>">
                  </div>
                  <div class="mb-3">
                    <label for="nfd" class="form-label">No Of Days:</label>
                    <input type="text" name="nfd" id="fees" class="form-control" value="<?php echo $row['nfd']; ?>">
                  </div>
                  <div class="mb-3">
                    <label for="simulation" class="form-label">Simulation:</label>
                    <input type="text" name="simulation" id="simulation" class="form-control" value="<?php echo $row['simulation']; ?>">
                  </div>
                    <div class="mb-3">
                    <label for="onroad" class="form-label">On Road:</label>
                    <input type="text" name="onroad" id="onroad" class="form-control" value="<?php echo $row['onroad']; ?>">
                  </div>
                    <div class="mb-3">
                    <label for="theory" class="form-label">Theory:</label>
                    <input type="text" name="theory" id="theory" class="form-control" value="<?php echo $row['theory']; ?>">
                  </div>
                    <div class="mb-3">
                    <label for="reverse" class="form-label">Reverse:</label>
                    <input type="text" name="reverse" id="reverse" class="form-control" value="<?php echo $row['reverse']; ?>">
                  </div>
                   <div class="mb-3">
                    <label for="testround" class="form-label">Test Round:</label>
                    <input type="text" name="testround" id="testround" class="form-control" value="<?php echo $row['testround']; ?>">
                  </div>
                  <input type="hidden" name="class_id" value="<?php echo $class_id; ?>">
                  <input type="submit" value="Update" name="update" class="btn btn-primary">
                </fieldset>
              </form>
            </div>
          </div>
        </div>
      </div>
      <?php
    }
  } else {
    echo "<tr><td colspan='6'>No classes found</td></tr>";
  }
  ?>
</tbody>


            
              </table>
            </div>





            
            <div class="card-footer text-center">
              <a href="classes.php"><button class="btn btn-danger">+ Add Classes</button></a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php
include("admin-footer.php");
?>
