<?php
include("admin-header.php");
?>   

<!-- partial -->
<div class="container-fluid page-body-wrapper">
  <div class="main-panel">
    <div class="content-wrapper">
      <div class="row">

        <div class="col-md-8 mx-auto mt-5">
          <div class="card shadow-sm">
            <div class="card-header bg-danger text-white">
              <h1 class="mb-0">Discount</h1>
            </div>
            <div class="card-body table-responsive">
              <table id="myTable" class="table table-striped table-bordered">
                <thead>
                  <tr>
                    <th>S.No</th>
                    <th>Name</th>
                    <th>Classes</th>
                    <th>Day Of Admission</th>
                    <th>Total Amount</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  <!-- Add more rows as needed -->
                </tbody>
              </table>
            </div>
            <div class="card-footer text-center">
              <a href="discount.php"><button class="btn btn-danger">+ Add Discount</button></a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- content-wrapper ends -->
    <!-- partial:../../partials/_footer.html -->

    <!-- partial -->
  </div>
  <!-- main-panel ends -->
</div>
<!-- page-body-wrapper ends -->

<?php
include("admin-footer.php");
?>
