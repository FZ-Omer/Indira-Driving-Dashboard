<?php
// Database connection and query to retrieve RC class details
include("../../connect.php");

$selectedClass = $_POST["class"]; // Assuming you are sending the selected class in the AJAX request

if ($selectedClass === "RC") {
  // Retrieve RC class details
  $sql = "SELECT * FROM classes_rc";
  $result = $conn->query($sql);

  // Build the HTML table to display the class details
  $html = '<table class="table">';
  $html .= '<thead><tr><th>ID</th><th>Class Name</th><th>Working</th><th>Fees</th><th>NFD</th></tr></thead>';
  $html .= '<tbody>';
  // Loop through the query results and create table rows
  while ($row = $result->fetch_assoc()) {
    $html .= '<tr>';
    $html .= '<td>' . $row['id'] . '</td>';
    $html .= '<td>' . $row['class_name'] . '</td>';
    $html .= '<td>' . $row['working'] . '</td>';
    $html .= '<td>' . $row['fees'] . '</td>';
    $html .= '<td>' . $row['nfd'] . '</td>';
    $html .= '</tr>';
  }
  $html .= '</tbody>';
  $html .= '</table>';

  echo $html;
} else {
  echo ""; // Return an empty response if no class is selected or if the selected class is not RC
}

?>
