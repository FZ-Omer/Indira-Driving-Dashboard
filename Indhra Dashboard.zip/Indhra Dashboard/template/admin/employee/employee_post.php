
<?php
include("../../../connect.php");

if (isset($_POST['staff_details'])) {
    $name = $_POST['name'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $role = $_POST['role'];
    $phone = $_POST['phone'];
    $dateOfJoining = $_POST['date_of_joining'];
    $salaryAmount = $_POST['salary_amount'];
    $salaryDate = $_POST['salary_date'];
    $dailyAllowance = $_POST['daily_allowance'];
    $bonus = $_POST['bonus'];
    $workingTime = $_POST['working_time'];
    $increment = $_POST['increment'];

        

        // Update remaining stock in product_sale table
        $sql = "INSERT INTO staff (name, username, password, role, phone, date_of_joining, salary_amount, salary_date, daily_allowance, bonus, working_time, increment) VALUES ('$name', '$username', '$password', '$role', '$phone', '$dateOfJoining', '$salaryAmount', '$salaryDate', '$dailyAllowance', '$bonus', '$workingTime', '$increment')";
        $result = mysqli_query($conn, $sql);
        if ($result) {
            $error = 'Your Staff Details Uploaded Successfully!';
            header("Location: employee_list.php?error=" . urlencode($error));
          } else {
            echo "Error: " . mysqli_error($conn);
          }
    }
    
   

?>