<?php
include("../../connect.php");

if (isset($_POST['update'])) {
  $class_id = $_POST['class_id'];
  $package_name = $_POST['package_name'];
  $fees = $_POST['fees'];
  $nfd = $_POST['nfd'];
  $simulation = $_POST['simulation'];
  $onroad = $_POST['onroad'];
  $theory = $_POST['theory'];
  $reverse = $_POST['reverse'];
  $testround = $_POST['testround'];

  // Update the class details in the database
  $sql = "UPDATE classes_dl SET package_name='$package_name', fees='$fees', nfd='$nfd', simulation='$simulation', onroad='$onroad', theory='$theory', reverse='$reverse', testround='$testround' WHERE id='$class_id'";
  $result = $conn->query($sql);

  if ($result === TRUE) {
    echo "Record updated successfully.";
  } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
  }
}
?>
