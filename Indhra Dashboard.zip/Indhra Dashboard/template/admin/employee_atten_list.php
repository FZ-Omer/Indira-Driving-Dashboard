<?php
include("admin-header.php");
include '../../connect.php';
?>

<style>
  .name-col {
    font-weight: bold;
  }
  .attend-col {
    text-align: center;
  }
  .attend-col input[type="checkbox"] {
    margin: 0 auto;
    display: block;
  }
  .missed-col {
    font-weight: bold;
    text-align: center;
  }
  thead {
    background-color: #001f3f;
    color: #fff;
    padding: 0.5em 1em;
  }
  td {
    border-top: 1px solid #eee;
    padding: 0.5em 1em;
  }
  .table-responsive {
    overflow-x: auto;
  }
</style>

<!-- partial -->
<div class="container-fluid page-body-wrapper">
  <div class="main-panel">
    <div class="content-wrapper">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-md-12">
            <div class="card shadow-sm">
              <div class="card-header bg-danger text-white" >
                <h1 class="mb-0">Staff Attendance</h1>
              </div>
              <div class="card-body" style="box-shadow: rgba(0, 0, 0, 0.17) 0px -23px 25px 0px inset, rgba(0, 0, 0, 0.15) 0px -36px 30px 0px inset, rgba(0, 0, 0, 0.1) 0px -79px 40px 0px inset, rgba(0, 0, 0, 0.06) 0px 2px 1px, rgba(0, 0, 0, 0.09) 0px 4px 2px, rgba(0, 0, 0, 0.09) 0px 8px 4px, rgba(0, 0, 0, 0.09) 0px 16px 8px, rgba(0, 0, 0, 0.09) 0px 32px 16px;">
                <div class="table-responsive">
                  <table class="table table-bordered">
                    <thead>
                      <tr>
                        <th>Name</th>
                        <?php
                        // Get the current month and year
                        $currentMonth = date('m');
                        $currentYear = date('Y');
                        $totalDays = cal_days_in_month(CAL_GREGORIAN, $currentMonth, $currentYear);

                        // Generate the table header with the day numbers
                        for ($day = 1; $day <= $totalDays; $day++) {
                          echo "<th>$day</th>";
                        }
                        ?>
                        <th class="missed-col">Days Missed</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                      // Assuming you have a database connection already established
                      $sql = "SELECT * FROM staff"; // Replace with your actual query
                      $result = mysqli_query($conn, $sql);

                      while ($row = mysqli_fetch_assoc($result)) {
                        $name = $row['name'];

                        echo "<tr>";
                        echo "<td class='name-col'>$name</td>";

                        for ($day = 1; $day <= $totalDays; $day++) {
                          $attendanceValue = ""; // Default value
                          $attendanceSql = "SELECT attendance FROM staff_attendance WHERE name = '$name' AND day = $day";
                          $attendanceResult = mysqli_query($conn, $attendanceSql);
                          if (mysqli_num_rows($attendanceResult) > 0) {
                            $attendanceRow = mysqli_fetch_assoc($attendanceResult);
                            $attendanceValue = $attendanceRow['attendance'];
                          }

                          echo "<td class='attend-col'>";
                          echo "<label class='checkbox-label'>";
                          if ($attendanceValue == 'P') {
                            echo "<input type='checkbox' name='attendance[$name][$day]' value='P' checked>";
                          } else {
                            echo "<input type='checkbox' name='attendance[$name][$day]' value='P'>";
                          }
                          echo "</label>";
                          echo "</td>";
                        }

                        echo "<td class='missed-col'>0</td>";
                        echo "</tr>";
                      }
                      ?>
                    </tbody>
                  </table>
                </div>
                <div class="text-center">
                  <button type="submit" class="btn btn-primary">Submit</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php
include("admin-footer.php");
?>
