<?php
include("../../connect.php");

if (isset($_GET['id'])) {
  $class_id = $_GET['id'];

  // Check if the user confirmed the deletion
  if (isset($_GET['confirm']) && $_GET['confirm'] === 'yes') {
    // Delete the class from the database
    $sql = "DELETE FROM classes_rc WHERE id='$class_id'";
    $result = $conn->query($sql);

    if ($result === TRUE) {
      echo "Record deleted successfully.";
    } else {
      echo "Error: " . $sql . "<br>" . $conn->error;
    }
  } else {
    // Show confirmation message
    echo "<script>
          if (confirm('Are you sure you want to delete this record?')) {
            window.location.href = 'employee-delete.php?id=$class_id&confirm=yes';
          } else {
            window.location.href = 'classes_list.php';
          }
        </script>";
  }
}

?>
